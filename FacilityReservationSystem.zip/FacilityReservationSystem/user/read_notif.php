<?php 
session_start();
include('connection.php');
include('tags.php');
$username = $_SESSION['username'];
//$query = mysqli_query($conn, "SELECT * FROM tbl_vehicle_reservation");
$vehicle_query = mysqli_query($conn, "UPDATE tbl_vehicle_reservation SET status_notif='Read' WHERE status='Paid by User' AND username='$username'");
$gymnasium_query = mysqli_query($conn, "UPDATE tbl_gymnasium_reservation SET status_notif='Read' WHERE status='Paid by User' AND username='$username'");
$otherfacilities_query = mysqli_query($conn, "UPDATE tbl_otherfacilities_reservation SET status_notif='Read' WHERE status='Paid by User' AND username='$username'");
echo mysqli_num_rows($vehicle_query) + mysqli_num_rows($gymnasium_query) + mysqli_num_rows($otherfacilities_query);

?>