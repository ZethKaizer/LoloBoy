<?php 

    include('connection.php');
    include('tags.php');
session_start();    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php 
        include('header.php');
    ?>

    <div class='container fontStyle' style='margin-top: 150px;'>
    <div class='row'>
    <div class='well well-lg col-md-8 col-md-offset-2' style='border: solid 1px green; background-color: #deffde; ' >
        <h1 class='text-center'>Request sent successfully.</h1>
       <h1 class='text-center lead'> Your request to reserve is now pending. To be able to view your pending request, you can check it on your <br>
       <a href="profile_info.php" class='lead'>Transaction History</a> </h1>
       </div>
    </div>
    </div>
</body>
</html>