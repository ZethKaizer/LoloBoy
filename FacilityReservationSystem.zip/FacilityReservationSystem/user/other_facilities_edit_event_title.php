<?php
include('connection.php');

$sql_date_between = mysqli_query($conn, "SELECT * FROM tbl_otherfacilities_reservation WHERE start BETWEEN '$start' AND '$end' AND title='$title' AND color='#0071c5'");
	

if (isset($_POST['delete']) && isset($_POST['id'])){	
	$id = $_POST['id'];
	$deleteQuery = mysqli_query($conn, "DELETE FROM tbl_otherfacilities_reservation WHERE id = $id");
//	$res = mysqli_query($conn, $deleteQuery);	
}



elseif (isset($_POST['title']) && isset($_POST['color']) && isset($_POST['id'])){
	$id = $_POST['id'];
	$title = $_POST['title'];
	$color = $_POST['color'];	
	$status = $_POST['status'];
	if($color=='#10538c'){ //dark blue
		$updateQuery = mysqli_query($conn, "UPDATE tbl_otherfacilities_reservation SET title = '$title', color = '$color', status = 'Reserved By School' WHERE id = $id");
	}
	elseif($color=='#147b20'){ //green
		$updateQuery = mysqli_query($conn, "UPDATE tbl_otherfacilities_reservation SET title = '$title', color = '$color', status = 'Reserved By User' WHERE id = $id");
	}
	else{
		$updateQuery = mysqli_query($conn, "UPDATE tbl_otherfacilities_reservation SET title = '$title', color = '$color', status = 'Reserved and Paid By User' WHERE id = $id");
	}

	//$res = mysqli_query($updateQuery, $sql);

	}
header('Location: gymnasium_reservation.php');	
?>
