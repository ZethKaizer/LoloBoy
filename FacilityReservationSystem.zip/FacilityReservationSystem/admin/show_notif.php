
<style>
#alert_popover{
	position:fixed; 
    bottom: 0px; 
    left: 0px; 
    width: 100%;
    z-index:9999; 
    border-radius:0px
}

#inner-message {
    margin: 0 auto;
}</style>

<?php 
session_start();
include('connection.php');
include('tags.php');

$username = $_SESSION['username'];

$vehicle_query = mysqli_query($conn, "SELECT * FROM tbl_vehicle_reservation 
WHERE status='Pending' ORDER BY id DESC;");

$gymnasium_query = mysqli_query($conn, "SELECT * FROM tbl_gymnasium_reservation
WHERE status='Pending' ORDER BY id DESC");


$otherfacilities_query = mysqli_query($conn, "SELECT * FROM tbl_otherfacilities_reservation
WHERE status='Pending' ORDER BY id DESC");

$total_notif = mysqli_num_rows($otherfacilities_query) + mysqli_num_rows($gymnasium_query) + mysqli_num_rows($vehicle_query); 

echo '<b><li class="dropdown-header">TOTAL NOTIFICATIONS: '.$total_notif.' </li></b>';
echo '<li class="divider"></li>';

echo '<li class="dropdown-header">Gymnasium Notification</li>';

if(mysqli_num_rows($gymnasium_query) > 0){
    while($row = mysqli_fetch_array($gymnasium_query)){ 

        echo '
        <div style="font-size: 13px; background: #f9f9f9; padding: 5px; margin: 5px; width: 300px; ">
        <a href="gymnasium_reservation.php">
        <b>'.$row['name'].'</b> sent you a request to reserve gymnasium <b>'.$row['title'].'</b></a>
            <br/>
        </div>
        ';
        }
}
else{
    echo 'No records yet.';

}

echo '<li class="divider"></li>';

echo '<li class="dropdown-header">Other Facilities</li>';   

if(mysqli_num_rows($otherfacilities_query) > 0){
    while($row = mysqli_fetch_array($otherfacilities_query)){ 
        echo '
        
        <div style="font-size: 13px; background: #f9f9f9; padding: 5px; margin: 5px; width: 300px; ">
        <a href="other_facilities_reservation.php">
    
        '.$row['name'].' sent you a request to reserve <b>'.$row['title'].'</b>
            <br/>
            </a>
            </div>
        ';
        }
}
else{
    echo 'No Records Yet';
}



echo '<li class="divider"></li>';

echo '<li class="dropdown-header">Vehicle Notification</li>';   

if(mysqli_num_rows($vehicle_query) > 0){
    while($row = mysqli_fetch_array($vehicle_query)){ 
        echo '
        
        <div style="font-size: 13px; background: #f9f9f9; padding: 5px; margin: 5px; width: 300px; ">
        <a href="vehicle_reservation.php">
    
        <b>'.$row['name'].'</b> sent you a request to reserve vehicle <b>'.$row['title'].'</b>
            <br/>
            </a>
        </div>
        ';
        }
}
else{
    echo 'No Records Yet';
}



/*
else {
    echo '<li class="text-center" style="padding: 5px;">No new Notification</li>';
                 
}
*/

?>
