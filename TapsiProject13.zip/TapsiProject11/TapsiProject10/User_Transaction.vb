﻿Imports MySql.Data.MySqlClient

Public Class User_Transaction
    Dim conn As MySqlConnection
    Dim cmd As MySqlCommand
    Dim dr As MySqlDataReader
    Dim da As MySqlDataAdapter
    Dim dt As DataTable

    Dim myConnection As MySqlConnection = New MySqlConnection


    ReadOnly CONNECTION_STRING As String = "datasource=localhost;port=3306;username=root;password=;database=pos_db"


    Sub compute()
        Dim sum As Integer = 0
        If MetroGrid1.Rows.Count > 0 Then
            TextBox1.Text = Total().ToString("0.00")

            For i As Integer = 0 To MetroGrid1.Rows.Count() - 1 Step +1
                sum = sum + MetroGrid1.Rows(i).Cells(1).Value
            Next

            TextBox2.Text = sum.ToString()

        End If
    End Sub

    Private Function Total() As Double
        Dim tot As Double = 0
        Dim i As Integer = 0
        For i = 0 To MetroGrid1.Rows.Count - 1
            tot = tot + Convert.ToDouble(MetroGrid1.Rows(i).Cells(2).Value)
        Next i
        Return tot

    End Function

    Private Sub MetroGrid1_CellValueChanged(sender As Object, e As DataGridViewCellEventArgs) Handles MetroGrid1.CellValueChanged
        compute()
    End Sub

    Private Sub User_Transaction_Load(sender As Object, e As EventArgs) Handles Me.Load
        MetroGrid1.Columns.Add("Items", "Items")
        MetroGrid1.Columns.Add("Quantity", "Quantity")
        MetroGrid1.Columns.Add("Amount", "Amount")

        MetroGrid1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        MetroGrid1.Columns(0).Width = 200

        Timer1.Enabled = True
        MetroTabPage1.AutoScroll = True
        transactID()
        TextBox1.Enabled = True
        TextBox2.Enabled = True
        btnCancel.Enabled = True
        btnFinalOrder.Enabled = True
        btnOrderSlip.Enabled = False
        TextBox3.Enabled = False
        TextBox4.Enabled = False

    End Sub


    Private Sub MetroButton17_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Dim index As Integer
        index = MetroGrid1.CurrentCell.RowIndex
        MetroGrid1.Rows.RemoveAt(index)
        compute()
    End Sub



    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click

    End Sub

    Private Sub MetroButton1_Click_1(sender As Object, e As EventArgs) Handles MetroButton1.Click
        Dim price1 As Integer = 80

        For Each row As DataGridViewRow In MetroGrid1.Rows
            If row.Cells(0).Value = "Tapsi Combo" Then
                row.Cells(1).Value = Integer.Parse(row.Cells(1).Value) + 1
                row.Cells(2).Value = Integer.Parse(row.Cells(1).Value) * price1
                Exit Sub
            End If

        Next
        MetroGrid1.Rows.Add("Tapsi Combo", "1", price1)
        compute()
    End Sub

    Private Sub MetroButton2_Click_1(sender As Object, e As EventArgs) Handles MetroButton2.Click
        Dim price1 As Integer = 70

        For Each row As DataGridViewRow In MetroGrid1.Rows
            If row.Cells(0).Value = "Tapsilog" Then
                row.Cells(1).Value = Integer.Parse(row.Cells(1).Value) + 1
                row.Cells(2).Value = Integer.Parse(row.Cells(1).Value) * price1
                Exit Sub
            End If

        Next
        MetroGrid1.Rows.Add("Tapsilog", "1", price1)
        compute()
    End Sub

    Private Sub MetroButton3_Click_1(sender As Object, e As EventArgs) Handles MetroButton3.Click
        Dim price1 As Integer = 80

        For Each row As DataGridViewRow In MetroGrid1.Rows
            If row.Cells(0).Value = "Spicy Tapsilog" Then
                row.Cells(1).Value = Integer.Parse(row.Cells(1).Value) + 1
                row.Cells(2).Value = Integer.Parse(row.Cells(1).Value) * price1
                Exit Sub
            End If

        Next
        MetroGrid1.Rows.Add("Spicy Tapsilog", "1", price1)
        compute()
    End Sub

    Private Sub MetroButton4_Click_1(sender As Object, e As EventArgs) Handles MetroButton4.Click
        Dim price1 As Integer = 80

        For Each row As DataGridViewRow In MetroGrid1.Rows
            If row.Cells(0).Value = "Tosilog Combo" Then
                row.Cells(1).Value = Integer.Parse(row.Cells(1).Value) + 1
                row.Cells(2).Value = Integer.Parse(row.Cells(1).Value) * price1
                Exit Sub
            End If

        Next
        MetroGrid1.Rows.Add("Tosilog Combo", "1", price1)
        compute()
    End Sub

    Private Sub MetroButton20_Click(sender As Object, e As EventArgs) Handles MetroButton20.Click
        Me.Hide()
        Login.Show()
    End Sub



    Private bitmap As Bitmap
    Private Sub PrintDocument1_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        e.Graphics.DrawImage(bitmap, 0, 0)
        Dim rectPrint As RectangleF = e.PageSettings.PrintableArea
        If Me.MetroGrid1.Height - rectPrint.Height > 0 Then
            e.HasMorePages = True
        End If

    End Sub

    Public Sub loadData()
        Dim conn As New MySqlConnection(CONNECTION_STRING)
        Dim table As New DataTable
        Dim da As New MySqlDataAdapter("Select * from tbl_transact", conn)
        da.Fill(table)
        MetroGrid1.DataSource = table
        Timer1.Enabled = True
    End Sub

    Private Sub transactID()
        Dim cmd As MySqlCommand
        Dim CN As New MySqlConnection(CONNECTION_STRING)

        CN.Open()
        cmd = New MySqlCommand("select * from tbl_transact", CN)
        cmd.Connection = CN
        Dim maxid As Object
        Dim strid As String
        Dim intid As Integer

        cmd.CommandText = "Select Max(id) as MaxID from tbl_transact"

        maxid = cmd.ExecuteScalar

        If maxid Is DBNull.Value Then
            intid = 1
        Else
            strid = CType(maxid, String)
            intid = CType(maxid, String)
            intid = intid + 1
        End If
        Label6.Text = intid
        CN.Close()

    End Sub


    Public Sub saveOrder()

        Dim conn As New MySqlConnection(CONNECTION_STRING)
        conn.Open()
        cmd = New MySqlCommand
        cmd.Connection = conn
        cmd.CommandText = "INSERT INTO `tbl_transact`(`id`, `total_amount`, `total_items`, `transact_money`, `transact_change`, `transact_date`, `transact_time`) 
                            VALUES ('" & Label6.Text & "', '" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "', '" & TextBox4.Text & "', '" & Label7.Text & "', '" & Label8.Text & "')"
        MessageBox.Show(cmd.CommandText)
        cmd.ExecuteNonQuery()
        conn.Close()
    End Sub

    Private Sub btnFinalOrder_Click(sender As Object, e As EventArgs) Handles btnFinalOrder.Click
        If MetroFramework.MetroMessageBox.Show(Me, "Are you sure, that is all your order?", "System Ask", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) Then
            TextBox1.Enabled = False
            TextBox2.Enabled = False
            btnCancel.Enabled = False
            btnFinalOrder.Enabled = False
            btnOrderSlip.Enabled = True
            TextBox3.Enabled = True
            TextBox4.Enabled = True
        End If
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Label7.Text = Date.Now.ToString("MMMM dd, yyyy") 'Automatic Date
        Label8.Text = Date.Now.ToString("hh:mm:ss: tt") 'Automatic Time
    End Sub

    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox1.KeyPress
        e.Handled = True 'Para hindi siya makapag-enter ng kahit anong text
    End Sub

    Private Sub TextBox2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox2.KeyPress
        e.Handled = True 'Para hindi siya makapag-enter ng kahit anong text

    End Sub

    Private Sub btnOrderSlip_Click(sender As Object, e As EventArgs) Handles btnOrderSlip.Click
        Dim int As Double = Val(TextBox3.Text)
        Dim dt As New DataTable

        If Val(TextBox1.Text) > int Then
            MetroFramework.MetroMessageBox.Show(Me, "Insufficient Money!", "Please Enter your Exact Amount", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return 'Return na if insufficient money para di n tumuloy sa codes sa baba
        ElseIf TextBox3.Text = "" Then
            MetroFramework.MetroMessageBox.Show(Me, "", "Please Enter your Exact Amount", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            TextBox4.Text = int - Val(TextBox1.Text)
            MetroFramework.MetroMessageBox.Show(Me, "Thank you for ordering with us!", "Please come again.", MessageBoxButtons.OK, MessageBoxIcon.Information)
            MsgBox("Your Change is " & TextBox4.Text)
            Admin_PrintOrderSlip.Show()
            saveOrder()
        End If

        'Dim report As New CrystalReport1
        'report.SetParameterValue("Time", txtValue.Text)
        'CrystalReportView1.ReportSource = report

        With dt
            .Columns.Add("Items")
            .Columns.Add("Quantity")
            .Columns.Add("Amount")
        End With

        For Each dr As DataGridViewRow In Me.MetroGrid1.Rows
            dt.Rows.Add(dr.Cells(0).Value, dr.Cells(1).Value, dr.Cells(2).Value)
        Next

        Dim rptDoc As CrystalDecisions.CrystalReports.Engine.ReportDocument
        rptDoc = New CrystalReport1
        rptDoc.SetDataSource(dt)
        '
        Admin_PrintOrderSlip.CrystalReportViewer1.ReportSource = rptDoc
        
        Me.Controls.Clear() 'removes all the controls on the form
        InitializeComponent() 'load all the controls again
        User_Transaction_Load(e, e)
    End Sub

    Private Sub MetroButton5_Click(sender As Object, e As EventArgs) Handles MetroButton5.Click
        Dim price1 As Integer = 100

        For Each row As DataGridViewRow In MetroGrid1.Rows
            If row.Cells(0).Value = "Chicksilog Combo" Then
                row.Cells(1).Value = Integer.Parse(row.Cells(1).Value) + 1
                row.Cells(2).Value = Integer.Parse(row.Cells(1).Value) * price1
                Exit Sub
            End If

        Next
        MetroGrid1.Rows.Add("Chicksilog Combo", "1", price1)
        compute()
    End Sub

    Private Sub MetroButton6_Click(sender As Object, e As EventArgs) Handles MetroButton6.Click
        Dim price1 As Integer = 70

        For Each row As DataGridViewRow In MetroGrid1.Rows
            If row.Cells(0).Value = "Longsilog" Then
                row.Cells(1).Value = Integer.Parse(row.Cells(1).Value) + 1
                row.Cells(2).Value = Integer.Parse(row.Cells(1).Value) * price1
                Exit Sub
            End If

        Next
        MetroGrid1.Rows.Add("Longsilog", "1", price1)
        compute()
    End Sub

    Private Sub MetroButton7_Click(sender As Object, e As EventArgs) Handles MetroButton7.Click
        Dim price1 As Integer = 80

        For Each row As DataGridViewRow In MetroGrid1.Rows
            If row.Cells(0).Value = "Longsilog Combo" Then
                row.Cells(1).Value = Integer.Parse(row.Cells(1).Value) + 1
                row.Cells(2).Value = Integer.Parse(row.Cells(1).Value) * price1
                Exit Sub
            End If

        Next
        MetroGrid1.Rows.Add("Longsilog Combo", "1", price1)
        compute()
    End Sub

    Private Sub MetroButton8_Click(sender As Object, e As EventArgs) Handles MetroButton8.Click
        Dim price1 As Integer = 70

        For Each row As DataGridViewRow In MetroGrid1.Rows
            If row.Cells(0).Value = "Tosilog" Then
                row.Cells(1).Value = Integer.Parse(row.Cells(1).Value) + 1
                row.Cells(2).Value = Integer.Parse(row.Cells(1).Value) * price1
                Exit Sub
            End If

        Next
        MetroGrid1.Rows.Add("Tosilog", "1", price1)
        compute()
    End Sub

    Private Sub MetroButton9_Click(sender As Object, e As EventArgs) Handles MetroButton9.Click
        Dim price1 As Integer = 130

        For Each row As DataGridViewRow In MetroGrid1.Rows
            If row.Cells(0).Value = "Breaded Porkchop Combo" Then
                row.Cells(1).Value = Integer.Parse(row.Cells(1).Value) + 1
                row.Cells(2).Value = Integer.Parse(row.Cells(1).Value) * price1
                Exit Sub
            End If

        Next
        MetroGrid1.Rows.Add("Breaded Porkchop Combo", "1", price1)
        compute()
    End Sub

    Private Sub MetroButton10_Click(sender As Object, e As EventArgs) Handles MetroButton10.Click
        Dim price1 As Integer = 100

        For Each row As DataGridViewRow In MetroGrid1.Rows
            If row.Cells(0).Value = "Lechon Kawali with Rice" Then
                row.Cells(1).Value = Integer.Parse(row.Cells(1).Value) + 1
                row.Cells(2).Value = Integer.Parse(row.Cells(1).Value) * price1
                Exit Sub
            End If

        Next
        MetroGrid1.Rows.Add("Lechon Kawali with Rice", "1", price1)
        compute()
    End Sub

    Private Sub MetroButton11_Click(sender As Object, e As EventArgs) Handles MetroButton11.Click
        Dim price1 As Integer = 135

        For Each row As DataGridViewRow In MetroGrid1.Rows
            If row.Cells(0).Value = "Lechon Kawali Combo" Then
                row.Cells(1).Value = Integer.Parse(row.Cells(1).Value) + 1
                row.Cells(2).Value = Integer.Parse(row.Cells(1).Value) * price1
                Exit Sub
            End If

        Next
        MetroGrid1.Rows.Add("Lechon Kawali Combo", "1", price1)
        compute()
    End Sub

    Private Sub MetroButton12_Click(sender As Object, e As EventArgs) Handles MetroButton12.Click
        Dim price1 As Integer = 90

        For Each row As DataGridViewRow In MetroGrid1.Rows
            If row.Cells(0).Value = "Chicksilog" Then
                row.Cells(1).Value = Integer.Parse(row.Cells(1).Value) + 1
                row.Cells(2).Value = Integer.Parse(row.Cells(1).Value) * price1
                Exit Sub
            End If

        Next
        MetroGrid1.Rows.Add("Chicksilog", "1", price1)
        compute()
    End Sub

    Private Sub MetroButton16_Click(sender As Object, e As EventArgs) Handles MetroButton16.Click
        Dim price1 As Integer = 95

        For Each row As DataGridViewRow In MetroGrid1.Rows
            If row.Cells(0).Value = "Breaded Porkchop" Then
                row.Cells(1).Value = Integer.Parse(row.Cells(1).Value) + 1
                row.Cells(2).Value = Integer.Parse(row.Cells(1).Value) * price1
                Exit Sub
            End If

        Next
        MetroGrid1.Rows.Add("Breaded Porkchop", "1", price1)
        compute()
    End Sub

    Private Sub MetroButton13_Click(sender As Object, e As EventArgs) Handles MetroButton13.Click
        Dim price1 As Integer = 135

        For Each row As DataGridViewRow In MetroGrid1.Rows
            If row.Cells(0).Value = "Boneless Bangus Combo" Then
                row.Cells(1).Value = Integer.Parse(row.Cells(1).Value) + 1
                row.Cells(2).Value = Integer.Parse(row.Cells(1).Value) * price1
                Exit Sub
            End If

        Next
        MetroGrid1.Rows.Add("Boneless Bangus Combo", "1", price1)
        compute()
    End Sub

    Private Sub MetroButton14_Click(sender As Object, e As EventArgs) Handles MetroButton14.Click
        Dim price1 As Integer = 100

        For Each row As DataGridViewRow In MetroGrid1.Rows
            If row.Cells(0).Value = "Sisig With Rice" Then
                row.Cells(1).Value = Integer.Parse(row.Cells(1).Value) + 1
                row.Cells(2).Value = Integer.Parse(row.Cells(1).Value) * price1
                Exit Sub
            End If

        Next
        MetroGrid1.Rows.Add("Sisig With Rice", "1", price1)
        compute()
    End Sub

    Private Sub MetroButton15_Click(sender As Object, e As EventArgs) Handles MetroButton15.Click
        Dim price1 As Integer = 140

        For Each row As DataGridViewRow In MetroGrid1.Rows
            If row.Cells(0).Value = "Sisig Combo" Then
                row.Cells(1).Value = Integer.Parse(row.Cells(1).Value) + 1
                row.Cells(2).Value = Integer.Parse(row.Cells(1).Value) * price1
                Exit Sub
            End If

        Next
        MetroGrid1.Rows.Add("Sisig Combo", "1", price1)
        compute()
    End Sub
End Class