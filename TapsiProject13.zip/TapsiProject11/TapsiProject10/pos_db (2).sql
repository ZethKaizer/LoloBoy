-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 28, 2020 at 12:39 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pos_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_transact`
--

CREATE TABLE `tbl_transact` (
  `id` int(20) NOT NULL,
  `total_amount` varchar(50) NOT NULL,
  `total_items` varchar(30) NOT NULL,
  `transact_money` varchar(50) NOT NULL,
  `transact_change` varchar(50) NOT NULL,
  `transact_date` varchar(50) NOT NULL,
  `transact_time` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_transact`
--

INSERT INTO `tbl_transact` (`id`, `total_amount`, `total_items`, `transact_money`, `transact_change`, `transact_date`, `transact_time`) VALUES
(1, '150.00', '2', '300', '0', '0', ''),
(2, '460.00', '6', '600', '0', '0', ''),
(3, '280.00', '4', '500', '220', 'January 28, 2020', '04:17:43: AM'),
(4, '750.00', '10', '800', '50', 'January 28, 2020', '05:22:42: AM'),
(5, '450.00', '6', '600', '150', 'January 28, 2020', '05:26:12: AM'),
(6, '520.00', '7', '600', '80', 'January 28, 2020', '05:58:35: AM'),
(7, '610.00', '8', '700', '90', 'January 28, 2020', '06:13:17: AM'),
(8, '770.00', '10', '800', '30', 'January 28, 2020', '06:15:03: AM'),
(9, '380.00', '5', '500', '120', 'January 28, 2020', '06:21:14: AM'),
(10, '480.00', '6', '600', '120', 'January 28, 2020', '06:27:46: AM'),
(11, '460.00', '6', '500', '40', 'January 28, 2020', '06:36:44: AM'),
(12, '390.00', '5', '500', '110', 'January 28, 2020', '06:37:36: AM'),
(13, '400.00', '5', '500', '100', 'January 28, 2020', '06:43:33: AM'),
(14, '700.00', '9', '1000', '300', 'January 28, 2020', '06:51:06: AM'),
(15, '2105.00', '22', '3000', '895', 'January 28, 2020', '07:38:02: AM');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `email` varchar(100) NOT NULL,
  `usertype` varchar(20) NOT NULL,
  `date_created` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `username`, `password`, `email`, `usertype`, `date_created`) VALUES
(1, 'Eric Yeoj Soriano', 'admin', 'admin', 'ericjeoj@gmail.com', 'User', 'January 19, 2020'),
(2, 'b4214b', '', '', '', '', 'January 19, 2020');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_transact`
--
ALTER TABLE `tbl_transact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_transact`
--
ALTER TABLE `tbl_transact`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
