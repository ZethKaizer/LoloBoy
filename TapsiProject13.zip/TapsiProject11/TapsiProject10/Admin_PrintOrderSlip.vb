﻿'Imports CrystalDecisions.CrystalReports.Engine
'Imports CrystalDecisions.Shared
Public Class Admin_PrintOrderSlip
    Private Sub Admin_PrintOrderSlip_Load(sender As Object, e As EventArgs) Handles Me.Load
        ' Dim rptDoc As ReportDocument
        ' rptDoc = New CrystalReport1

        '     'View Report in Crystal Report Viewer
        '       Me.CrystalReportViewer1.ReportSource = rptDoc
        Me.WindowState = FormWindowState.Maximized

    End Sub
End Class