﻿Imports MySql.Data.MySqlClient

Public Class User_Transaction

    Dim cmd As MySqlCommand
    Dim dr As MySqlDataReader
    Dim da As MySqlDataAdapter


    ReadOnly CONNECTION_STRING As String = "datasource=localhost;port=3306;username=root;password=;database=pos_db"
    Dim conn As New MySqlConnection(CONNECTION_STRING)


    Sub compute()
        Dim sum As Integer = 0
        If MetroGrid1.Rows.Count > 0 Then
            TextBox1.Text = Total().ToString("0.00")

            For i As Integer = 0 To MetroGrid1.Rows.Count() - 1 Step +1
                sum = sum + MetroGrid1.Rows(i).Cells(1).Value
            Next

            TextBox2.Text = sum.ToString()

        End If
    End Sub

    Private Function Total() As Double
        Dim tot As Double = 0
        Dim i As Integer = 0
        For i = 0 To MetroGrid1.Rows.Count - 1
            tot = tot + Convert.ToDouble(MetroGrid1.Rows(i).Cells(2).Value)
        Next i
        Return tot
    End Function
    Private Sub MetroGrid1_CellValueChanged(sender As Object, e As DataGridViewCellEventArgs)
        compute()
    End Sub

    Private Sub User_Transaction_Load(sender As Object, e As EventArgs) Handles Me.Load
        MetroTabPage1.AutoScroll = True
        transactID()
        Timer1.Enabled = True
    End Sub






    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click

    End Sub

    Private Sub MetroButton1_Click_1(sender As Object, e As EventArgs) Handles MetroButton1.Click
        Dim price1 As Integer = 80

        For Each row As DataGridViewRow In MetroGrid1.Rows
            If row.Cells(0).Value = "Tapsi Combo" Then
                row.Cells(1).Value = Integer.Parse(row.Cells(1).Value) + 1
                row.Cells(2).Value = Integer.Parse(row.Cells(1).Value) * price1
                Exit Sub
            End If

        Next
        MetroGrid1.Rows.Add("Tapsi Combo", "1", price1)
        compute()
    End Sub

    Private Sub MetroButton2_Click_1(sender As Object, e As EventArgs) Handles MetroButton2.Click
        Dim price1 As Integer = 70

        For Each row As DataGridViewRow In MetroGrid1.Rows
            If row.Cells(0).Value = "Tapsilog" Then
                row.Cells(1).Value = Integer.Parse(row.Cells(1).Value) + 1
                row.Cells(2).Value = Integer.Parse(row.Cells(1).Value) * price1
                Exit Sub
            End If

        Next
        MetroGrid1.Rows.Add("Tapsilog", "1", price1)
        compute()
    End Sub

    Private Sub MetroButton3_Click_1(sender As Object, e As EventArgs) Handles MetroButton3.Click
        Dim price1 As Integer = 80

        For Each row As DataGridViewRow In MetroGrid1.Rows
            If row.Cells(0).Value = "Spicy Tapsilog" Then
                row.Cells(1).Value = Integer.Parse(row.Cells(1).Value) + 1
                row.Cells(2).Value = Integer.Parse(row.Cells(1).Value) * price1
                Exit Sub
            End If

        Next
        MetroGrid1.Rows.Add("Spicy Tapsilog", "1", price1)
        compute()
    End Sub

    Private Sub MetroButton4_Click_1(sender As Object, e As EventArgs) Handles MetroButton4.Click
        Dim price1 As Integer = 80

        For Each row As DataGridViewRow In MetroGrid1.Rows
            If row.Cells(0).Value = "Tosilog Combo" Then
                row.Cells(1).Value = Integer.Parse(row.Cells(1).Value) + 1
                row.Cells(2).Value = Integer.Parse(row.Cells(1).Value) * price1
                Exit Sub
            End If

        Next
        MetroGrid1.Rows.Add("Tosilog Combo", "1", price1)
        compute()
    End Sub

    Private bitmap As Bitmap


    Private Sub MetroButton18_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub PrintDocument1_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        e.Graphics.DrawImage(bitmap, 0, 0)
        Dim rectPrint As RectangleF = e.PageSettings.PrintableArea
        If Me.MetroGrid1.Height - rectPrint.Height > 0 Then
            e.HasMorePages = True
        End If

    End Sub

    Private Sub MetroButton17_Click_1(sender As Object, e As EventArgs) Handles MetroButton17.Click
        Dim index As Integer
        index = MetroGrid1.CurrentCell.RowIndex
        MetroGrid1.Rows.RemoveAt(index)
        compute()
    End Sub

    Private Sub MetroButton18_Click_1(sender As Object, e As EventArgs) Handles MetroButton18.Click

        saveOrder()
    End Sub

    Public Sub saveOrder()
        Dim conn As New MySqlConnection(CONNECTION_STRING)
        conn.Open()
        cmd = New MySqlCommand
        cmd.Connection = conn
        cmd.CommandText = "INSERT INTO [tbl_transaction]([transact_id], [total_amount], [total_items], [money], [change], [transaction_date]) VALUES('" & Label6.Text & "', '" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "', '" & TextBox4.Text & "', '" & Label7.Text & "')"
        MessageBox.Show(cmd.CommandText)
        cmd.ExecuteNonQuery()
        conn.Close()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Label7.Text = Date.Now.ToString("MMMM dd, yyyy")
    End Sub


    Private Sub transactID()
        Dim cmd As MySqlCommand
        Dim CN As New MySqlConnection(CONNECTION_STRING)

        CN.Open()
        cmd = New MySqlCommand("select * from tbl_transaction", CN)
        cmd.Connection = CN
        Dim maxid As Object
        Dim strid As String
        Dim intid As Integer

        cmd.CommandText = "Select Max(transact_id) as MaxID from tbl_transaction"

        maxid = cmd.ExecuteScalar

        If maxid Is DBNull.Value Then
            intid = 1
        Else
            strid = CType(maxid, String)
            intid = CType(maxid, String)
            intid = intid + 1
        End If
        Label6.Text = intid
        CN.Close()

    End Sub

    Private Sub Label7_Click(sender As Object, e As EventArgs) Handles Label7.Click

    End Sub
End Class