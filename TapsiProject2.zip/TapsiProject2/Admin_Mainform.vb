﻿Imports System.Drawing.Text
Public Class Admin_Mainform
    Private Sub Admin_Mainform_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CustomFont()
    End Sub

    Private Sub CustomFont() 'Importing Custom Font (Montserrat Font)
        Dim pfc As New PrivateFontCollection

        pfc.AddFontFile("montserrat/Montserrat-Light.otf")
        BunifuFlatButton1.TextFont = New Font(pfc.Families(0), 12)
        BunifuFlatButton2.TextFont = New Font(pfc.Families(0), 12)
        BunifuFlatButton4.TextFont = New Font(pfc.Families(0), 12)
        BunifuFlatButton5.TextFont = New Font(pfc.Families(0), 12)

        pfc.AddFontFile("montserrat/Montserrat-SemiBold.otf")
        Label3.Font = New Font(pfc.Families(1), 15)

        pfc.AddFontFile("montserrat/Montserrat-Black.otf")
        Label8.Font = New Font(pfc.Families(2), 20)



    End Sub

    Private Sub BunifuFlatButton4_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton4.Click

    End Sub
End Class