﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class User_Transaction
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.BunifuElipse1 = New Bunifu.Framework.UI.BunifuElipse(Me.components)
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.MetroTabControl1 = New MetroFramework.Controls.MetroTabControl()
        Me.MetroTabPage1 = New MetroFramework.Controls.MetroTabPage()
        Me.MetroButton13 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton14 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton15 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton16 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton9 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton10 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton11 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton12 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton5 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton6 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton7 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton8 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton4 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton3 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton2 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton1 = New MetroFramework.Controls.MetroButton()
        Me.MetroTabPage2 = New MetroFramework.Controls.MetroTabPage()
        Me.MetroTabPage3 = New MetroFramework.Controls.MetroTabPage()
        Me.MetroTabPage4 = New MetroFramework.Controls.MetroTabPage()
        Me.MetroTabPage5 = New MetroFramework.Controls.MetroTabPage()
        Me.MetroTabPage6 = New MetroFramework.Controls.MetroTabPage()
        Me.MetroTabPage7 = New MetroFramework.Controls.MetroTabPage()
        Me.MetroTabPage8 = New MetroFramework.Controls.MetroTabPage()
        Me.MetroTabPage9 = New MetroFramework.Controls.MetroTabPage()
        Me.MetroGrid1 = New MetroFramework.Controls.MetroGrid()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.MetroButton17 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton18 = New MetroFramework.Controls.MetroButton()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.MetroButton19 = New MetroFramework.Controls.MetroButton()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MetroTabControl1.SuspendLayout()
        Me.MetroTabPage1.SuspendLayout()
        CType(Me.MetroGrid1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'BunifuElipse1
        '
        Me.BunifuElipse1.ElipseRadius = 5
        Me.BunifuElipse1.TargetControl = Me
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(186, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1040, 101)
        Me.Panel1.TabIndex = 0
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.TapsiProject.My.Resources.Resources.TapsiLogo
        Me.PictureBox1.Location = New System.Drawing.Point(12, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(113, 99)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 6
        Me.PictureBox1.TabStop = False
        '
        'MetroTabControl1
        '
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage1)
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage2)
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage3)
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage4)
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage5)
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage6)
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage7)
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage8)
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage9)
        Me.MetroTabControl1.Dock = System.Windows.Forms.DockStyle.Left
        Me.MetroTabControl1.Location = New System.Drawing.Point(0, 101)
        Me.MetroTabControl1.Name = "MetroTabControl1"
        Me.MetroTabControl1.SelectedIndex = 0
        Me.MetroTabControl1.Size = New System.Drawing.Size(620, 529)
        Me.MetroTabControl1.TabIndex = 1
        Me.MetroTabControl1.UseSelectable = True
        '
        'MetroTabPage1
        '
        Me.MetroTabPage1.Controls.Add(Me.MetroButton13)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton14)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton15)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton16)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton9)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton10)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton11)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton12)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton5)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton6)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton7)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton8)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton4)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton3)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton2)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton1)
        Me.MetroTabPage1.HorizontalScrollbarBarColor = True
        Me.MetroTabPage1.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroTabPage1.HorizontalScrollbarSize = 10
        Me.MetroTabPage1.Location = New System.Drawing.Point(4, 38)
        Me.MetroTabPage1.Name = "MetroTabPage1"
        Me.MetroTabPage1.Size = New System.Drawing.Size(612, 487)
        Me.MetroTabPage1.TabIndex = 0
        Me.MetroTabPage1.Text = "Foods"
        Me.MetroTabPage1.VerticalScrollbarBarColor = True
        Me.MetroTabPage1.VerticalScrollbarHighlightOnWheel = False
        Me.MetroTabPage1.VerticalScrollbarSize = 10
        '
        'MetroButton13
        '
        Me.MetroButton13.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton13.Location = New System.Drawing.Point(452, 417)
        Me.MetroButton13.Name = "MetroButton13"
        Me.MetroButton13.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton13.TabIndex = 17
        Me.MetroButton13.Text = "MetroButton13"
        Me.MetroButton13.UseSelectable = True
        '
        'MetroButton14
        '
        Me.MetroButton14.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton14.Location = New System.Drawing.Point(304, 417)
        Me.MetroButton14.Name = "MetroButton14"
        Me.MetroButton14.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton14.TabIndex = 16
        Me.MetroButton14.Text = "MetroButton14"
        Me.MetroButton14.UseSelectable = True
        '
        'MetroButton15
        '
        Me.MetroButton15.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton15.Location = New System.Drawing.Point(156, 417)
        Me.MetroButton15.Name = "MetroButton15"
        Me.MetroButton15.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton15.TabIndex = 15
        Me.MetroButton15.Text = "MetroButton15"
        Me.MetroButton15.UseSelectable = True
        '
        'MetroButton16
        '
        Me.MetroButton16.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton16.Location = New System.Drawing.Point(8, 417)
        Me.MetroButton16.Name = "MetroButton16"
        Me.MetroButton16.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton16.TabIndex = 14
        Me.MetroButton16.Text = "Tapsi Combo - 80"
        Me.MetroButton16.UseCustomForeColor = True
        Me.MetroButton16.UseSelectable = True
        Me.MetroButton16.UseStyleColors = True
        '
        'MetroButton9
        '
        Me.MetroButton9.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton9.Location = New System.Drawing.Point(452, 283)
        Me.MetroButton9.Name = "MetroButton9"
        Me.MetroButton9.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton9.TabIndex = 13
        Me.MetroButton9.Text = "MetroButton9"
        Me.MetroButton9.UseSelectable = True
        '
        'MetroButton10
        '
        Me.MetroButton10.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton10.Location = New System.Drawing.Point(304, 283)
        Me.MetroButton10.Name = "MetroButton10"
        Me.MetroButton10.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton10.TabIndex = 12
        Me.MetroButton10.Text = "Lechon Kawali with " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Rice" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "100"
        Me.MetroButton10.UseSelectable = True
        '
        'MetroButton11
        '
        Me.MetroButton11.DisplayFocus = True
        Me.MetroButton11.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton11.Location = New System.Drawing.Point(156, 283)
        Me.MetroButton11.Name = "MetroButton11"
        Me.MetroButton11.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton11.TabIndex = 11
        Me.MetroButton11.Text = "Lechon Kawali " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Combo" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "135"
        Me.MetroButton11.UseSelectable = True
        '
        'MetroButton12
        '
        Me.MetroButton12.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton12.Location = New System.Drawing.Point(8, 283)
        Me.MetroButton12.Name = "MetroButton12"
        Me.MetroButton12.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton12.TabIndex = 10
        Me.MetroButton12.Text = "Chicksilog" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "90"
        Me.MetroButton12.UseCustomForeColor = True
        Me.MetroButton12.UseSelectable = True
        Me.MetroButton12.UseStyleColors = True
        '
        'MetroButton5
        '
        Me.MetroButton5.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton5.Location = New System.Drawing.Point(452, 149)
        Me.MetroButton5.Name = "MetroButton5"
        Me.MetroButton5.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton5.TabIndex = 9
        Me.MetroButton5.Text = "Chicksilog Combo" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "100"
        Me.MetroButton5.UseSelectable = True
        '
        'MetroButton6
        '
        Me.MetroButton6.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton6.Location = New System.Drawing.Point(304, 149)
        Me.MetroButton6.Name = "MetroButton6"
        Me.MetroButton6.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton6.TabIndex = 8
        Me.MetroButton6.Text = "Longsilog" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "70"
        Me.MetroButton6.UseSelectable = True
        '
        'MetroButton7
        '
        Me.MetroButton7.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton7.Location = New System.Drawing.Point(156, 149)
        Me.MetroButton7.Name = "MetroButton7"
        Me.MetroButton7.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton7.TabIndex = 7
        Me.MetroButton7.Text = "Longsilog Combo" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "80"
        Me.MetroButton7.UseSelectable = True
        '
        'MetroButton8
        '
        Me.MetroButton8.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton8.Location = New System.Drawing.Point(8, 149)
        Me.MetroButton8.Name = "MetroButton8"
        Me.MetroButton8.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton8.TabIndex = 6
        Me.MetroButton8.Text = "Tosilog" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "70"
        Me.MetroButton8.UseCustomForeColor = True
        Me.MetroButton8.UseSelectable = True
        Me.MetroButton8.UseStyleColors = True
        '
        'MetroButton4
        '
        Me.MetroButton4.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton4.Location = New System.Drawing.Point(452, 15)
        Me.MetroButton4.Name = "MetroButton4"
        Me.MetroButton4.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton4.TabIndex = 5
        Me.MetroButton4.Text = "Tosilog Combo" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "80"
        Me.MetroButton4.UseSelectable = True
        '
        'MetroButton3
        '
        Me.MetroButton3.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton3.Location = New System.Drawing.Point(304, 15)
        Me.MetroButton3.Name = "MetroButton3"
        Me.MetroButton3.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton3.TabIndex = 4
        Me.MetroButton3.Text = "Spicy Tapsilog " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "80"
        Me.MetroButton3.UseSelectable = True
        '
        'MetroButton2
        '
        Me.MetroButton2.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton2.Location = New System.Drawing.Point(156, 15)
        Me.MetroButton2.Name = "MetroButton2"
        Me.MetroButton2.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton2.TabIndex = 3
        Me.MetroButton2.Text = "Tapsilog " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "70"
        Me.MetroButton2.UseSelectable = True
        '
        'MetroButton1
        '
        Me.MetroButton1.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton1.Location = New System.Drawing.Point(8, 15)
        Me.MetroButton1.Name = "MetroButton1"
        Me.MetroButton1.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton1.TabIndex = 2
        Me.MetroButton1.Text = "Tapsi Combo " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "80"
        Me.MetroButton1.UseCustomForeColor = True
        Me.MetroButton1.UseSelectable = True
        Me.MetroButton1.UseStyleColors = True
        '
        'MetroTabPage2
        '
        Me.MetroTabPage2.HorizontalScrollbarBarColor = True
        Me.MetroTabPage2.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroTabPage2.HorizontalScrollbarSize = 10
        Me.MetroTabPage2.Location = New System.Drawing.Point(4, 38)
        Me.MetroTabPage2.Name = "MetroTabPage2"
        Me.MetroTabPage2.Size = New System.Drawing.Size(605, 487)
        Me.MetroTabPage2.TabIndex = 1
        Me.MetroTabPage2.Text = "Drinks"
        Me.MetroTabPage2.VerticalScrollbarBarColor = True
        Me.MetroTabPage2.VerticalScrollbarHighlightOnWheel = False
        Me.MetroTabPage2.VerticalScrollbarSize = 10
        '
        'MetroTabPage3
        '
        Me.MetroTabPage3.HorizontalScrollbarBarColor = True
        Me.MetroTabPage3.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroTabPage3.HorizontalScrollbarSize = 10
        Me.MetroTabPage3.Location = New System.Drawing.Point(4, 38)
        Me.MetroTabPage3.Name = "MetroTabPage3"
        Me.MetroTabPage3.Size = New System.Drawing.Size(605, 487)
        Me.MetroTabPage3.TabIndex = 2
        Me.MetroTabPage3.Text = "Sandwiches"
        Me.MetroTabPage3.VerticalScrollbarBarColor = True
        Me.MetroTabPage3.VerticalScrollbarHighlightOnWheel = False
        Me.MetroTabPage3.VerticalScrollbarSize = 10
        '
        'MetroTabPage4
        '
        Me.MetroTabPage4.HorizontalScrollbarBarColor = True
        Me.MetroTabPage4.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroTabPage4.HorizontalScrollbarSize = 10
        Me.MetroTabPage4.Location = New System.Drawing.Point(4, 38)
        Me.MetroTabPage4.Name = "MetroTabPage4"
        Me.MetroTabPage4.Size = New System.Drawing.Size(605, 487)
        Me.MetroTabPage4.TabIndex = 3
        Me.MetroTabPage4.Text = "Ala Carte"
        Me.MetroTabPage4.VerticalScrollbarBarColor = True
        Me.MetroTabPage4.VerticalScrollbarHighlightOnWheel = False
        Me.MetroTabPage4.VerticalScrollbarSize = 10
        '
        'MetroTabPage5
        '
        Me.MetroTabPage5.HorizontalScrollbarBarColor = True
        Me.MetroTabPage5.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroTabPage5.HorizontalScrollbarSize = 10
        Me.MetroTabPage5.Location = New System.Drawing.Point(4, 38)
        Me.MetroTabPage5.Name = "MetroTabPage5"
        Me.MetroTabPage5.Size = New System.Drawing.Size(605, 487)
        Me.MetroTabPage5.TabIndex = 4
        Me.MetroTabPage5.Text = "Desserts"
        Me.MetroTabPage5.VerticalScrollbarBarColor = True
        Me.MetroTabPage5.VerticalScrollbarHighlightOnWheel = False
        Me.MetroTabPage5.VerticalScrollbarSize = 10
        '
        'MetroTabPage6
        '
        Me.MetroTabPage6.HorizontalScrollbarBarColor = True
        Me.MetroTabPage6.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroTabPage6.HorizontalScrollbarSize = 10
        Me.MetroTabPage6.Location = New System.Drawing.Point(4, 38)
        Me.MetroTabPage6.Name = "MetroTabPage6"
        Me.MetroTabPage6.Size = New System.Drawing.Size(605, 487)
        Me.MetroTabPage6.TabIndex = 5
        Me.MetroTabPage6.Text = "Extras"
        Me.MetroTabPage6.VerticalScrollbarBarColor = True
        Me.MetroTabPage6.VerticalScrollbarHighlightOnWheel = False
        Me.MetroTabPage6.VerticalScrollbarSize = 10
        '
        'MetroTabPage7
        '
        Me.MetroTabPage7.HorizontalScrollbarBarColor = True
        Me.MetroTabPage7.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroTabPage7.HorizontalScrollbarSize = 10
        Me.MetroTabPage7.Location = New System.Drawing.Point(4, 38)
        Me.MetroTabPage7.Name = "MetroTabPage7"
        Me.MetroTabPage7.Size = New System.Drawing.Size(605, 487)
        Me.MetroTabPage7.TabIndex = 6
        Me.MetroTabPage7.Text = "Binalot"
        Me.MetroTabPage7.VerticalScrollbarBarColor = True
        Me.MetroTabPage7.VerticalScrollbarHighlightOnWheel = False
        Me.MetroTabPage7.VerticalScrollbarSize = 10
        '
        'MetroTabPage8
        '
        Me.MetroTabPage8.HorizontalScrollbarBarColor = True
        Me.MetroTabPage8.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroTabPage8.HorizontalScrollbarSize = 10
        Me.MetroTabPage8.Location = New System.Drawing.Point(4, 38)
        Me.MetroTabPage8.Name = "MetroTabPage8"
        Me.MetroTabPage8.Size = New System.Drawing.Size(605, 487)
        Me.MetroTabPage8.TabIndex = 7
        Me.MetroTabPage8.Text = "Short Orders"
        Me.MetroTabPage8.VerticalScrollbarBarColor = True
        Me.MetroTabPage8.VerticalScrollbarHighlightOnWheel = False
        Me.MetroTabPage8.VerticalScrollbarSize = 10
        '
        'MetroTabPage9
        '
        Me.MetroTabPage9.HorizontalScrollbarBarColor = True
        Me.MetroTabPage9.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroTabPage9.HorizontalScrollbarSize = 10
        Me.MetroTabPage9.Location = New System.Drawing.Point(4, 38)
        Me.MetroTabPage9.Name = "MetroTabPage9"
        Me.MetroTabPage9.Size = New System.Drawing.Size(605, 487)
        Me.MetroTabPage9.TabIndex = 8
        Me.MetroTabPage9.Text = "Other Specials"
        Me.MetroTabPage9.VerticalScrollbarBarColor = True
        Me.MetroTabPage9.VerticalScrollbarHighlightOnWheel = False
        Me.MetroTabPage9.VerticalScrollbarSize = 10
        '
        'MetroGrid1
        '
        Me.MetroGrid1.AllowUserToResizeRows = False
        Me.MetroGrid1.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.MetroGrid1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.MetroGrid1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None
        Me.MetroGrid1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(174, Byte), Integer), CType(CType(219, Byte), Integer))
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Segoe UI", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel)
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(198, Byte), Integer), CType(CType(247, Byte), Integer))
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.MetroGrid1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.MetroGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Segoe UI", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel)
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(136, Byte), Integer), CType(CType(136, Byte), Integer), CType(CType(136, Byte), Integer))
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(198, Byte), Integer), CType(CType(247, Byte), Integer))
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.MetroGrid1.DefaultCellStyle = DataGridViewCellStyle2
        Me.MetroGrid1.Dock = System.Windows.Forms.DockStyle.Top
        Me.MetroGrid1.EnableHeadersVisualStyles = False
        Me.MetroGrid1.Font = New System.Drawing.Font("Segoe UI", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel)
        Me.MetroGrid1.GridColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.MetroGrid1.Location = New System.Drawing.Point(620, 101)
        Me.MetroGrid1.Name = "MetroGrid1"
        Me.MetroGrid1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(174, Byte), Integer), CType(CType(219, Byte), Integer))
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Segoe UI", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel)
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(198, Byte), Integer), CType(CType(247, Byte), Integer))
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.MetroGrid1.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.MetroGrid1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.MetroGrid1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.MetroGrid1.Size = New System.Drawing.Size(420, 299)
        Me.MetroGrid1.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI Light", 11.0!)
        Me.Label1.Location = New System.Drawing.Point(635, 426)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(97, 20)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Total Payment:"
        '
        'TextBox1
        '
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox1.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.TextBox1.Location = New System.Drawing.Point(738, 422)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(290, 27)
        Me.TextBox1.TabIndex = 6
        '
        'TextBox2
        '
        Me.TextBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox2.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.TextBox2.Location = New System.Drawing.Point(738, 457)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(290, 27)
        Me.TextBox2.TabIndex = 8
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI Light", 11.0!)
        Me.Label2.Location = New System.Drawing.Point(654, 459)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(77, 20)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Total Items:"
        '
        'TextBox3
        '
        Me.TextBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox3.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox3.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.TextBox3.Location = New System.Drawing.Point(738, 494)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(290, 27)
        Me.TextBox3.TabIndex = 10
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe UI Light", 11.0!)
        Me.Label3.Location = New System.Drawing.Point(633, 496)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(98, 20)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Enter Amount:"
        '
        'MetroButton17
        '
        Me.MetroButton17.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton17.Location = New System.Drawing.Point(639, 567)
        Me.MetroButton17.Name = "MetroButton17"
        Me.MetroButton17.Size = New System.Drawing.Size(125, 43)
        Me.MetroButton17.TabIndex = 11
        Me.MetroButton17.Text = "Cancel Item"
        Me.MetroButton17.UseSelectable = True
        '
        'MetroButton18
        '
        Me.MetroButton18.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton18.Location = New System.Drawing.Point(770, 567)
        Me.MetroButton18.Name = "MetroButton18"
        Me.MetroButton18.Size = New System.Drawing.Size(125, 43)
        Me.MetroButton18.TabIndex = 12
        Me.MetroButton18.Text = "Get Receipt"
        Me.MetroButton18.UseSelectable = True
        '
        'TextBox4
        '
        Me.TextBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox4.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox4.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.TextBox4.Location = New System.Drawing.Point(738, 530)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(290, 27)
        Me.TextBox4.TabIndex = 14
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Segoe UI Light", 11.0!)
        Me.Label4.Location = New System.Drawing.Point(671, 533)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(60, 20)
        Me.Label4.TabIndex = 13
        Me.Label4.Text = "Change:"
        '
        'MetroButton19
        '
        Me.MetroButton19.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton19.Location = New System.Drawing.Point(901, 567)
        Me.MetroButton19.Name = "MetroButton19"
        Me.MetroButton19.Size = New System.Drawing.Size(125, 43)
        Me.MetroButton19.TabIndex = 15
        Me.MetroButton19.Text = "New Transact"
        Me.MetroButton19.UseSelectable = True
        '
        'User_Transaction
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1040, 630)
        Me.Controls.Add(Me.MetroButton19)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.MetroButton18)
        Me.Controls.Add(Me.MetroButton17)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.MetroGrid1)
        Me.Controls.Add(Me.MetroTabControl1)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "User_Transaction"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "User_Transaction"
        Me.Panel1.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MetroTabControl1.ResumeLayout(False)
        Me.MetroTabPage1.ResumeLayout(False)
        CType(Me.MetroGrid1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents BunifuElipse1 As Bunifu.Framework.UI.BunifuElipse
    Friend WithEvents Panel1 As Panel
    Friend WithEvents MetroTabControl1 As MetroFramework.Controls.MetroTabControl
    Friend WithEvents MetroTabPage1 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents MetroTabPage2 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents MetroTabPage3 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents MetroTabPage4 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents MetroTabPage5 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents MetroTabPage6 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents MetroTabPage7 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents MetroTabPage8 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents MetroTabPage9 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents MetroButton1 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton9 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton10 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton11 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton12 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton5 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton6 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton7 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton8 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton4 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton3 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton2 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton13 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton14 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton15 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton16 As MetroFramework.Controls.MetroButton
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents MetroGrid1 As MetroFramework.Controls.MetroGrid
    Friend WithEvents Label1 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents MetroButton17 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton18 As MetroFramework.Controls.MetroButton
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents MetroButton19 As MetroFramework.Controls.MetroButton
End Class
