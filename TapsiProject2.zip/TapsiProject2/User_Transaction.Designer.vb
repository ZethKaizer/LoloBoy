﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class User_Transaction
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.BunifuElipse1 = New Bunifu.Framework.UI.BunifuElipse(Me.components)
        Me.BunifuElipse2 = New Bunifu.Framework.UI.BunifuElipse(Me.components)
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.MetroTabControl1 = New MetroFramework.Controls.MetroTabControl()
        Me.MetroTabPage1 = New MetroFramework.Controls.MetroTabPage()
        Me.MetroTabPage2 = New MetroFramework.Controls.MetroTabPage()
        Me.MetroTabPage3 = New MetroFramework.Controls.MetroTabPage()
        Me.MetroTabPage4 = New MetroFramework.Controls.MetroTabPage()
        Me.MetroTabPage5 = New MetroFramework.Controls.MetroTabPage()
        Me.MetroTabPage6 = New MetroFramework.Controls.MetroTabPage()
        Me.MetroTabPage7 = New MetroFramework.Controls.MetroTabPage()
        Me.MetroTabPage8 = New MetroFramework.Controls.MetroTabPage()
        Me.MetroTabPage9 = New MetroFramework.Controls.MetroTabPage()
        Me.MetroButton1 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton4 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton5 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton12 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton11 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton10 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton9 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton6 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton7 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton8 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton3 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton2 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton13 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton14 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton15 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton16 = New MetroFramework.Controls.MetroButton()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Panel1.SuspendLayout()
        Me.MetroTabControl1.SuspendLayout()
        Me.MetroTabPage1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'BunifuElipse1
        '
        Me.BunifuElipse1.ElipseRadius = 5
        Me.BunifuElipse1.TargetControl = Me
        '
        'BunifuElipse2
        '
        Me.BunifuElipse2.ElipseRadius = 5
        Me.BunifuElipse2.TargetControl = Me
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(186, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(970, 101)
        Me.Panel1.TabIndex = 0
        '
        'MetroTabControl1
        '
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage1)
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage2)
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage3)
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage4)
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage5)
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage6)
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage7)
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage8)
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage9)
        Me.MetroTabControl1.Dock = System.Windows.Forms.DockStyle.Left
        Me.MetroTabControl1.Location = New System.Drawing.Point(0, 101)
        Me.MetroTabControl1.Name = "MetroTabControl1"
        Me.MetroTabControl1.SelectedIndex = 0
        Me.MetroTabControl1.Size = New System.Drawing.Size(613, 529)
        Me.MetroTabControl1.TabIndex = 1
        Me.MetroTabControl1.UseSelectable = True
        '
        'MetroTabPage1
        '
        Me.MetroTabPage1.Controls.Add(Me.MetroButton13)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton14)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton15)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton16)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton9)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton10)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton11)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton12)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton5)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton6)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton7)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton8)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton4)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton3)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton2)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton1)
        Me.MetroTabPage1.HorizontalScrollbarBarColor = True
        Me.MetroTabPage1.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroTabPage1.HorizontalScrollbarSize = 10
        Me.MetroTabPage1.Location = New System.Drawing.Point(4, 38)
        Me.MetroTabPage1.Name = "MetroTabPage1"
        Me.MetroTabPage1.Size = New System.Drawing.Size(605, 487)
        Me.MetroTabPage1.TabIndex = 0
        Me.MetroTabPage1.Text = "Foods"
        Me.MetroTabPage1.VerticalScrollbarBarColor = True
        Me.MetroTabPage1.VerticalScrollbarHighlightOnWheel = False
        Me.MetroTabPage1.VerticalScrollbarSize = 10
        '
        'MetroTabPage2
        '
        Me.MetroTabPage2.HorizontalScrollbarBarColor = True
        Me.MetroTabPage2.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroTabPage2.HorizontalScrollbarSize = 10
        Me.MetroTabPage2.Location = New System.Drawing.Point(4, 38)
        Me.MetroTabPage2.Name = "MetroTabPage2"
        Me.MetroTabPage2.Size = New System.Drawing.Size(605, 487)
        Me.MetroTabPage2.TabIndex = 1
        Me.MetroTabPage2.Text = "Drinks"
        Me.MetroTabPage2.VerticalScrollbarBarColor = True
        Me.MetroTabPage2.VerticalScrollbarHighlightOnWheel = False
        Me.MetroTabPage2.VerticalScrollbarSize = 10
        '
        'MetroTabPage3
        '
        Me.MetroTabPage3.HorizontalScrollbarBarColor = True
        Me.MetroTabPage3.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroTabPage3.HorizontalScrollbarSize = 10
        Me.MetroTabPage3.Location = New System.Drawing.Point(4, 38)
        Me.MetroTabPage3.Name = "MetroTabPage3"
        Me.MetroTabPage3.Size = New System.Drawing.Size(605, 487)
        Me.MetroTabPage3.TabIndex = 2
        Me.MetroTabPage3.Text = "Sandwiches"
        Me.MetroTabPage3.VerticalScrollbarBarColor = True
        Me.MetroTabPage3.VerticalScrollbarHighlightOnWheel = False
        Me.MetroTabPage3.VerticalScrollbarSize = 10
        '
        'MetroTabPage4
        '
        Me.MetroTabPage4.HorizontalScrollbarBarColor = True
        Me.MetroTabPage4.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroTabPage4.HorizontalScrollbarSize = 10
        Me.MetroTabPage4.Location = New System.Drawing.Point(4, 38)
        Me.MetroTabPage4.Name = "MetroTabPage4"
        Me.MetroTabPage4.Size = New System.Drawing.Size(605, 487)
        Me.MetroTabPage4.TabIndex = 3
        Me.MetroTabPage4.Text = "Ala Carte"
        Me.MetroTabPage4.VerticalScrollbarBarColor = True
        Me.MetroTabPage4.VerticalScrollbarHighlightOnWheel = False
        Me.MetroTabPage4.VerticalScrollbarSize = 10
        '
        'MetroTabPage5
        '
        Me.MetroTabPage5.HorizontalScrollbarBarColor = True
        Me.MetroTabPage5.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroTabPage5.HorizontalScrollbarSize = 10
        Me.MetroTabPage5.Location = New System.Drawing.Point(4, 38)
        Me.MetroTabPage5.Name = "MetroTabPage5"
        Me.MetroTabPage5.Size = New System.Drawing.Size(577, 487)
        Me.MetroTabPage5.TabIndex = 4
        Me.MetroTabPage5.Text = "Desserts"
        Me.MetroTabPage5.VerticalScrollbarBarColor = True
        Me.MetroTabPage5.VerticalScrollbarHighlightOnWheel = False
        Me.MetroTabPage5.VerticalScrollbarSize = 10
        '
        'MetroTabPage6
        '
        Me.MetroTabPage6.HorizontalScrollbarBarColor = True
        Me.MetroTabPage6.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroTabPage6.HorizontalScrollbarSize = 10
        Me.MetroTabPage6.Location = New System.Drawing.Point(4, 38)
        Me.MetroTabPage6.Name = "MetroTabPage6"
        Me.MetroTabPage6.Size = New System.Drawing.Size(577, 487)
        Me.MetroTabPage6.TabIndex = 5
        Me.MetroTabPage6.Text = "Extras"
        Me.MetroTabPage6.VerticalScrollbarBarColor = True
        Me.MetroTabPage6.VerticalScrollbarHighlightOnWheel = False
        Me.MetroTabPage6.VerticalScrollbarSize = 10
        '
        'MetroTabPage7
        '
        Me.MetroTabPage7.HorizontalScrollbarBarColor = True
        Me.MetroTabPage7.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroTabPage7.HorizontalScrollbarSize = 10
        Me.MetroTabPage7.Location = New System.Drawing.Point(4, 38)
        Me.MetroTabPage7.Name = "MetroTabPage7"
        Me.MetroTabPage7.Size = New System.Drawing.Size(577, 487)
        Me.MetroTabPage7.TabIndex = 6
        Me.MetroTabPage7.Text = "Binalot"
        Me.MetroTabPage7.VerticalScrollbarBarColor = True
        Me.MetroTabPage7.VerticalScrollbarHighlightOnWheel = False
        Me.MetroTabPage7.VerticalScrollbarSize = 10
        '
        'MetroTabPage8
        '
        Me.MetroTabPage8.HorizontalScrollbarBarColor = True
        Me.MetroTabPage8.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroTabPage8.HorizontalScrollbarSize = 10
        Me.MetroTabPage8.Location = New System.Drawing.Point(4, 38)
        Me.MetroTabPage8.Name = "MetroTabPage8"
        Me.MetroTabPage8.Size = New System.Drawing.Size(577, 487)
        Me.MetroTabPage8.TabIndex = 7
        Me.MetroTabPage8.Text = "Short Orders"
        Me.MetroTabPage8.VerticalScrollbarBarColor = True
        Me.MetroTabPage8.VerticalScrollbarHighlightOnWheel = False
        Me.MetroTabPage8.VerticalScrollbarSize = 10
        '
        'MetroTabPage9
        '
        Me.MetroTabPage9.HorizontalScrollbarBarColor = True
        Me.MetroTabPage9.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroTabPage9.HorizontalScrollbarSize = 10
        Me.MetroTabPage9.Location = New System.Drawing.Point(4, 38)
        Me.MetroTabPage9.Name = "MetroTabPage9"
        Me.MetroTabPage9.Size = New System.Drawing.Size(577, 487)
        Me.MetroTabPage9.TabIndex = 8
        Me.MetroTabPage9.Text = "Other Specials"
        Me.MetroTabPage9.VerticalScrollbarBarColor = True
        Me.MetroTabPage9.VerticalScrollbarHighlightOnWheel = False
        Me.MetroTabPage9.VerticalScrollbarSize = 10
        '
        'MetroButton1
        '
        Me.MetroButton1.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton1.Location = New System.Drawing.Point(8, 15)
        Me.MetroButton1.Name = "MetroButton1"
        Me.MetroButton1.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton1.TabIndex = 2
        Me.MetroButton1.Text = "Tapsi Combo - 80"
        Me.MetroButton1.UseCustomForeColor = True
        Me.MetroButton1.UseSelectable = True
        Me.MetroButton1.UseStyleColors = True
        '
        'MetroButton4
        '
        Me.MetroButton4.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton4.Location = New System.Drawing.Point(452, 15)
        Me.MetroButton4.Name = "MetroButton4"
        Me.MetroButton4.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton4.TabIndex = 5
        Me.MetroButton4.Text = "MetroButton4"
        Me.MetroButton4.UseSelectable = True
        '
        'MetroButton5
        '
        Me.MetroButton5.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton5.Location = New System.Drawing.Point(452, 149)
        Me.MetroButton5.Name = "MetroButton5"
        Me.MetroButton5.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton5.TabIndex = 9
        Me.MetroButton5.Text = "MetroButton5"
        Me.MetroButton5.UseSelectable = True
        '
        'MetroButton12
        '
        Me.MetroButton12.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton12.Location = New System.Drawing.Point(8, 283)
        Me.MetroButton12.Name = "MetroButton12"
        Me.MetroButton12.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton12.TabIndex = 10
        Me.MetroButton12.Text = "Tapsi Combo - 80"
        Me.MetroButton12.UseCustomForeColor = True
        Me.MetroButton12.UseSelectable = True
        Me.MetroButton12.UseStyleColors = True
        '
        'MetroButton11
        '
        Me.MetroButton11.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton11.Location = New System.Drawing.Point(156, 283)
        Me.MetroButton11.Name = "MetroButton11"
        Me.MetroButton11.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton11.TabIndex = 11
        Me.MetroButton11.Text = "MetroButton11"
        Me.MetroButton11.UseSelectable = True
        '
        'MetroButton10
        '
        Me.MetroButton10.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton10.Location = New System.Drawing.Point(304, 283)
        Me.MetroButton10.Name = "MetroButton10"
        Me.MetroButton10.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton10.TabIndex = 12
        Me.MetroButton10.Text = "MetroButton10"
        Me.MetroButton10.UseSelectable = True
        '
        'MetroButton9
        '
        Me.MetroButton9.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton9.Location = New System.Drawing.Point(452, 283)
        Me.MetroButton9.Name = "MetroButton9"
        Me.MetroButton9.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton9.TabIndex = 13
        Me.MetroButton9.Text = "MetroButton9"
        Me.MetroButton9.UseSelectable = True
        '
        'MetroButton6
        '
        Me.MetroButton6.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton6.Location = New System.Drawing.Point(304, 149)
        Me.MetroButton6.Name = "MetroButton6"
        Me.MetroButton6.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton6.TabIndex = 8
        Me.MetroButton6.Text = "MetroButton6"
        Me.MetroButton6.UseSelectable = True
        '
        'MetroButton7
        '
        Me.MetroButton7.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton7.Location = New System.Drawing.Point(156, 149)
        Me.MetroButton7.Name = "MetroButton7"
        Me.MetroButton7.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton7.TabIndex = 7
        Me.MetroButton7.Text = "MetroButton7"
        Me.MetroButton7.UseSelectable = True
        '
        'MetroButton8
        '
        Me.MetroButton8.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton8.Location = New System.Drawing.Point(8, 149)
        Me.MetroButton8.Name = "MetroButton8"
        Me.MetroButton8.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton8.TabIndex = 6
        Me.MetroButton8.Text = "Tapsi Combo - 80"
        Me.MetroButton8.UseCustomForeColor = True
        Me.MetroButton8.UseSelectable = True
        Me.MetroButton8.UseStyleColors = True
        '
        'MetroButton3
        '
        Me.MetroButton3.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton3.Location = New System.Drawing.Point(304, 15)
        Me.MetroButton3.Name = "MetroButton3"
        Me.MetroButton3.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton3.TabIndex = 4
        Me.MetroButton3.Text = "MetroButton3"
        Me.MetroButton3.UseSelectable = True
        '
        'MetroButton2
        '
        Me.MetroButton2.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton2.Location = New System.Drawing.Point(156, 15)
        Me.MetroButton2.Name = "MetroButton2"
        Me.MetroButton2.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton2.TabIndex = 3
        Me.MetroButton2.Text = "Tapsilog - 70"
        Me.MetroButton2.UseSelectable = True
        '
        'MetroButton13
        '
        Me.MetroButton13.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton13.Location = New System.Drawing.Point(452, 417)
        Me.MetroButton13.Name = "MetroButton13"
        Me.MetroButton13.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton13.TabIndex = 17
        Me.MetroButton13.Text = "MetroButton13"
        Me.MetroButton13.UseSelectable = True
        '
        'MetroButton14
        '
        Me.MetroButton14.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton14.Location = New System.Drawing.Point(304, 417)
        Me.MetroButton14.Name = "MetroButton14"
        Me.MetroButton14.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton14.TabIndex = 16
        Me.MetroButton14.Text = "MetroButton14"
        Me.MetroButton14.UseSelectable = True
        '
        'MetroButton15
        '
        Me.MetroButton15.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton15.Location = New System.Drawing.Point(156, 417)
        Me.MetroButton15.Name = "MetroButton15"
        Me.MetroButton15.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton15.TabIndex = 15
        Me.MetroButton15.Text = "MetroButton15"
        Me.MetroButton15.UseSelectable = True
        '
        'MetroButton16
        '
        Me.MetroButton16.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton16.Location = New System.Drawing.Point(8, 417)
        Me.MetroButton16.Name = "MetroButton16"
        Me.MetroButton16.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton16.TabIndex = 14
        Me.MetroButton16.Text = "Tapsi Combo - 80"
        Me.MetroButton16.UseCustomForeColor = True
        Me.MetroButton16.UseSelectable = True
        Me.MetroButton16.UseStyleColors = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.TapsiProject.My.Resources.Resources.TapsiLogo
        Me.PictureBox1.Location = New System.Drawing.Point(12, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(113, 99)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 6
        Me.PictureBox1.TabStop = False
        '
        'User_Transaction
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(970, 630)
        Me.Controls.Add(Me.MetroTabControl1)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "User_Transaction"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "User_Transaction"
        Me.Panel1.ResumeLayout(False)
        Me.MetroTabControl1.ResumeLayout(False)
        Me.MetroTabPage1.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents BunifuElipse1 As Bunifu.Framework.UI.BunifuElipse
    Friend WithEvents BunifuElipse2 As Bunifu.Framework.UI.BunifuElipse
    Friend WithEvents Panel1 As Panel
    Friend WithEvents MetroTabControl1 As MetroFramework.Controls.MetroTabControl
    Friend WithEvents MetroTabPage1 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents MetroTabPage2 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents MetroTabPage3 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents MetroTabPage4 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents MetroTabPage5 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents MetroTabPage6 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents MetroTabPage7 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents MetroTabPage8 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents MetroTabPage9 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents MetroButton1 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton9 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton10 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton11 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton12 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton5 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton6 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton7 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton8 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton4 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton3 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton2 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton13 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton14 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton15 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton16 As MetroFramework.Controls.MetroButton
    Friend WithEvents PictureBox1 As PictureBox
End Class
