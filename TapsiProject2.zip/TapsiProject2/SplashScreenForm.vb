﻿'To Import Custom Font
Imports System.Drawing.Text


Public Class SplashScreenForm

    Private Sub SplashScreenForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        BunifuCircleProgressbar1.Value = 0
        Timer1.Start()
        CustomFont()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If BunifuCircleProgressbar1.Value = 100 Then
            Me.Hide()
            Login.Show()
        Else
            BunifuCircleProgressbar1.Value = BunifuCircleProgressbar1.Value + 1
        End If
    End Sub

    Private Sub CustomFont() 'Importing Custom Font (Montserrat Font)
        Dim pfc As New PrivateFontCollection

        pfc.AddFontFile("montserrat/Montserrat-Black.otf")
        Label1.Font = New Font(pfc.Families(0), 35, FontStyle.Regular)
        Label2.Font = New Font(pfc.Families(0), 50, FontStyle.Regular)

        pfc.AddFontFile("montserrat/Montserrat-Bold.otf")
        Label3.Font = New Font(pfc.Families(1), 40, FontStyle.Regular)
        BunifuCircleProgressbar1.Font = New Font(pfc.Families(1), 30, FontStyle.Regular)

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub
End Class