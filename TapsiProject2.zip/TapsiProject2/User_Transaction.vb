﻿Public Class User_Transaction
    Private Sub MetroTabPage3_Click(sender As Object, e As EventArgs) Handles MetroTabPage3.Click

    End Sub

    Private Sub MetroTabPage1_Click(sender As Object, e As EventArgs) Handles MetroTabPage1.Click
        MetroTabPage1.AutoScroll = True
    End Sub
End Class