﻿Imports MySql.Data.MySqlClient

Public Class Login
    Dim conn As MySqlConnection
    Dim cmd As MySqlCommand
    Dim dr As MySqlDataReader
    Dim da As MySqlDataAdapter
    ReadOnly CONNECTION_STRING As String = "datasource=localhost;port=3306;username=root;password=;database=pos_db"
    Private Sub Login_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub BunifuFlatButton2_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton2.Click
        Application.Exit()
    End Sub

    Private Sub BunifuFlatButton1_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton1.Click
        LoginButton()
    End Sub

    Private Sub LoginButton()
        Dim conn As New MySqlConnection(CONNECTION_STRING)
        Dim cmd As MySqlCommand = New MySqlCommand("select * from tbl_user where username='" & MaterialSingleLineTextField1.Text & "' and password ='" & MaterialSingleLineTextField2.Text & "'and usertype='" & MetroComboBox1.Text & "'", conn)
        Dim da As MySqlDataAdapter = New MySqlDataAdapter(cmd)
        Dim dt As DataTable = New DataTable()
        da.Fill(dt)


        If (dt.Rows.Count > 0) Then
            MetroFramework.MetroMessageBox.Show(Me, "Welcome, " + dt.Rows(0)(2) + "! Log In Successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
            If MetroComboBox1.SelectedIndex = 0 Then
                Dim a As New Admin_Mainform
                a.Show()
                Me.Hide()

            Else
                Dim b As New User_Transaction
                b.Show()
                Me.Hide()


            End If
        Else

            MetroFramework.MetroMessageBox.Show(Me, "The Username you entered is invalid! Please ask the Administrator before you log in.", "System Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If


        If MaterialSingleLineTextField1.Text = "" Then
            MetroFramework.MetroMessageBox.Show(Me, "Please Enter Your User Name!", "System Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf MaterialSingleLineTextField2.Text = "" Then
            MetroFramework.MetroMessageBox.Show(Me, "Please Enter Your Password!", "System Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf MetroComboBox1.Text = "" Then
            MetroFramework.MetroMessageBox.Show(Me, "Please Enter Your User Type!", "System Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else



        End If
    End Sub

    Private Sub loginSub()



    End Sub


End Class
