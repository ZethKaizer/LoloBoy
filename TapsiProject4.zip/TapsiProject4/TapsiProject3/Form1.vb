﻿Imports System.Data.Sql
Imports System.Data.SqlClient
Imports System.Drawing.Text

Public Class Login
    Private Sub Login_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CustomFont()
    End Sub

    Private Sub CustomFont() 'Importing Custom Font (Montserrat Font)
        Dim pfc, pfc1 As New PrivateFontCollection

        pfc.AddFontFile("montserrat/Montserrat-Light.otf")
        Label4.Font = New Font(pfc.Families(0), 13)
        Label5.Font = New Font(pfc.Families(0), 13)
        Label6.Font = New Font(pfc.Families(0), 13)
        BunifuFlatButton1.TextFont = New Font(pfc.Families(0), 13)

        pfc1.AddFontFile("montserrat/Montserrat-Black.otf")
        Label2.Font = New Font(pfc1.Families(0), 16)
        Label7.Font = New Font(pfc1.Families(0), 16)

    End Sub

End Class
