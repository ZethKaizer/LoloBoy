﻿Public Class User_Transaction
    Sub compute()
        Dim sum As Integer = 0
        If MetroGrid1.Rows.Count > 0 Then
            TextBox1.Text = Total().ToString("0.00")

            For i As Integer = 0 To MetroGrid1.Rows.Count() - 1 Step +1
                sum = sum + MetroGrid1.Rows(i).Cells(1).Value
            Next

            TextBox2.Text = sum.ToString()

        End If
    End Sub

    Private Function Total() As Double
        Dim tot As Double = 0
        Dim i As Integer = 0
        For i = 0 To MetroGrid1.Rows.Count - 1
            tot = tot + Convert.ToDouble(MetroGrid1.Rows(i).Cells(2).Value)
        Next i
        Return tot
    End Function
    Private Sub MetroGrid1_CellValueChanged(sender As Object, e As DataGridViewCellEventArgs) Handles MetroGrid1.CellValueChanged
        compute()
    End Sub

    Private Sub User_Transaction_Load(sender As Object, e As EventArgs) Handles Me.Load
        MetroTabPage1.AutoScroll = True
        
    End Sub


    Private Sub MetroButton17_Click(sender As Object, e As EventArgs) Handles MetroButton17.Click
        Dim index As Integer
        index = MetroGrid1.CurrentCell.RowIndex
        MetroGrid1.Rows.RemoveAt(index)
        compute()
    End Sub



    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click

    End Sub

    Private Sub MetroButton1_Click_1(sender As Object, e As EventArgs) Handles MetroButton1.Click
        Dim price1 As Integer = 80

        For Each row As DataGridViewRow In MetroGrid1.Rows
            If row.Cells(0).Value = "Tapsi Combo" Then
                row.Cells(1).Value = Integer.Parse(row.Cells(1).Value) + 1
                row.Cells(2).Value = Integer.Parse(row.Cells(1).Value) * price1
                Exit Sub
            End If

        Next
        MetroGrid1.Rows.Add("Tapsi Combo", "1", price1)
        compute()
    End Sub

    Private Sub MetroButton2_Click_1(sender As Object, e As EventArgs) Handles MetroButton2.Click
        Dim price1 As Integer = 70

        For Each row As DataGridViewRow In MetroGrid1.Rows
            If row.Cells(0).Value = "Tapsilog" Then
                row.Cells(1).Value = Integer.Parse(row.Cells(1).Value) + 1
                row.Cells(2).Value = Integer.Parse(row.Cells(1).Value) * price1
                Exit Sub
            End If

        Next
        MetroGrid1.Rows.Add("Tapsilog", "1", price1)
        compute()
    End Sub

    Private Sub MetroButton3_Click_1(sender As Object, e As EventArgs) Handles MetroButton3.Click
        Dim price1 As Integer = 80

        For Each row As DataGridViewRow In MetroGrid1.Rows
            If row.Cells(0).Value = "Spicy Tapsilog" Then
                row.Cells(1).Value = Integer.Parse(row.Cells(1).Value) + 1
                row.Cells(2).Value = Integer.Parse(row.Cells(1).Value) * price1
                Exit Sub
            End If

        Next
        MetroGrid1.Rows.Add("Spicy Tapsilog", "1", price1)
        compute()
    End Sub

    Private Sub MetroButton4_Click_1(sender As Object, e As EventArgs) Handles MetroButton4.Click
        Dim price1 As Integer = 80

        For Each row As DataGridViewRow In MetroGrid1.Rows
            If row.Cells(0).Value = "Tosilog Combo" Then
                row.Cells(1).Value = Integer.Parse(row.Cells(1).Value) + 1
                row.Cells(2).Value = Integer.Parse(row.Cells(1).Value) * price1
                Exit Sub
            End If

        Next
        MetroGrid1.Rows.Add("Tosilog Combo", "1", price1)
        compute()
    End Sub
End Class