-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 22, 2020 at 07:12 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `calendar`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin_credentials`
--

CREATE TABLE `tbl_admin_credentials` (
  `id` int(11) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `middle_name` varchar(200) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_admin_credentials`
--

INSERT INTO `tbl_admin_credentials` (`id`, `last_name`, `first_name`, `middle_name`, `username`, `password`) VALUES
(1, 'Olid', 'Henry', 'B', 'henry04', 'henry04'),
(3, '094', '094', '094', '094', '094');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_gymnasium_reservation`
--

CREATE TABLE `tbl_gymnasium_reservation` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `color` varchar(7) DEFAULT NULL,
  `start` datetime NOT NULL,
  `end` datetime DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(11) NOT NULL,
  `contact_number` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `status` varchar(50) NOT NULL,
  `status_notif` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_otherfacilies_reservation`
--

CREATE TABLE `tbl_otherfacilies_reservation` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `color` varchar(7) DEFAULT NULL,
  `start` datetime NOT NULL,
  `end` datetime DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(11) NOT NULL,
  `contact_number` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `status` varchar(50) NOT NULL,
  `status_notif` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_otherfacilities_reservation`
--

CREATE TABLE `tbl_otherfacilities_reservation` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `color` varchar(7) DEFAULT NULL,
  `start` datetime NOT NULL,
  `end` datetime DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(11) NOT NULL,
  `contact_number` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `status` varchar(50) NOT NULL,
  `status_notif` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_otherfacilities_reservation`
--

INSERT INTO `tbl_otherfacilities_reservation` (`id`, `title`, `color`, `start`, `end`, `name`, `username`, `contact_number`, `email`, `status`, `status_notif`) VALUES
(2, 'Gymnasium', '#0071c5', '2020-04-03 00:00:00', '2020-04-04 00:00:00', 'Henry B Olid', 'henry04', '', '', 'Reserved by School', ''),
(3, 'Gymnasium', '#a72d2a', '2020-04-04 00:00:00', '2020-04-05 00:00:00', 'Marks B Joseph', 'user', '09890', '9088903', 'Paid by User', 'Read');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_other_facilities`
--

CREATE TABLE `tbl_other_facilities` (
  `id` int(15) NOT NULL,
  `other_facilities` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_other_facilities`
--

INSERT INTO `tbl_other_facilities` (`id`, `other_facilities`) VALUES
(1, 'Gymnasium'),
(2, 'Avr - Nuevo'),
(3, 'MPH - Multi Purpose Hall'),
(4, 'Mini Hotel'),
(5, 'Kitchen Lab'),
(6, 'Cold Kitchen'),
(7, 'Big Room with Aircon'),
(8, 'Small Room without Aircon'),
(9, 'All Room Scie. 2nd Floor'),
(10, 'Demo Room Dimas'),
(11, 'AVR Dimas'),
(12, 'Grandstand Dimas');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_credentials`
--

CREATE TABLE `tbl_user_credentials` (
  `id` int(11) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `middle_name` varchar(200) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(15) NOT NULL,
  `email` varchar(100) NOT NULL,
  `contact_number` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_user_credentials`
--

INSERT INTO `tbl_user_credentials` (`id`, `last_name`, `first_name`, `middle_name`, `username`, `password`, `email`, `contact_number`) VALUES
(1, 'Joseph', 'Marks', 'B', 'user', 'user', '9088903', '09890'),
(2, '89898', '88989008', '9089089890', 'user1', 'user1', '3626262', '626322'),
(3, '988809098809089', '98089080089', '908089089089', '809809098', '089809089', '08980089', '098089809'),
(4, '980089089809', '098890098', '890089098', '098089080', '98089089', '08908089089', '08908909'),
(5, 'Cruz', 'Juan', 'Dela', 'juancruz', 'juancruz', 'juancruz@gmail.com', '09563561205'),
(6, 'Cruz', 'Jericho', 'Dela', 'jerichocruz', 'jerichocruz', 'jerichocruz@gmail.com', '09510935601'),
(8, '03', '03', '03', '03', '03', '03', '03'),
(9, '03', '03', '03', '05ssss', '05', '05', '005'),
(10, '030303', '03', '030', '0303', '03030', '30', '030');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_vehicle`
--

CREATE TABLE `tbl_vehicle` (
  `id` int(11) NOT NULL,
  `vehicle` varchar(200) NOT NULL,
  `plate_number` varchar(50) NOT NULL,
  `capacity` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_vehicle`
--

INSERT INTO `tbl_vehicle` (`id`, `vehicle`, `plate_number`, `capacity`) VALUES
(1, 'B Coaster 1', 'VG-5008', '28'),
(2, 'II Coaster 2', 'VG-5011', '28'),
(3, 'II Coaster 3', 'VG-5010', '28'),
(4, 'Isuzu Crosswind', 'ZJZ-493', '8'),
(5, 'Nissan Urban', 'AIA-8161', '18'),
(6, 'L-300/II Elf', 'UMT-896', '2');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_vehicle_reservation`
--

CREATE TABLE `tbl_vehicle_reservation` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `color` varchar(7) DEFAULT NULL,
  `start` datetime NOT NULL,
  `end` datetime DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(11) NOT NULL,
  `contact_number` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `status` varchar(50) NOT NULL,
  `status_notif` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin_credentials`
--
ALTER TABLE `tbl_admin_credentials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_gymnasium_reservation`
--
ALTER TABLE `tbl_gymnasium_reservation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_otherfacilies_reservation`
--
ALTER TABLE `tbl_otherfacilies_reservation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_otherfacilities_reservation`
--
ALTER TABLE `tbl_otherfacilities_reservation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_other_facilities`
--
ALTER TABLE `tbl_other_facilities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user_credentials`
--
ALTER TABLE `tbl_user_credentials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_vehicle`
--
ALTER TABLE `tbl_vehicle`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_vehicle_reservation`
--
ALTER TABLE `tbl_vehicle_reservation`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin_credentials`
--
ALTER TABLE `tbl_admin_credentials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_gymnasium_reservation`
--
ALTER TABLE `tbl_gymnasium_reservation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_otherfacilies_reservation`
--
ALTER TABLE `tbl_otherfacilies_reservation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_otherfacilities_reservation`
--
ALTER TABLE `tbl_otherfacilities_reservation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_other_facilities`
--
ALTER TABLE `tbl_other_facilities`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tbl_user_credentials`
--
ALTER TABLE `tbl_user_credentials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tbl_vehicle`
--
ALTER TABLE `tbl_vehicle`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_vehicle_reservation`
--
ALTER TABLE `tbl_vehicle_reservation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
