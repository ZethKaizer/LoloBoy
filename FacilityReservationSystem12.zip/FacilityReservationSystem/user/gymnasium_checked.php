
<?php 
session_start();
include('connection.php');
include('tags.php');
$username = $_SESSION['username'];
if(isset($_POST['check_query'])){		
	$showquery = mysqli_query($conn, "SELECT * FROM tbl_gymnasium_reservation WHERE NOT status='Pending' "); 
	$events = $showquery;
	while($row = mysqli_fetch_array($showquery)){ 
		echo '<div id="calendar"></div>';
        include('gymnasium_calendar.php');

	}

}
?>

