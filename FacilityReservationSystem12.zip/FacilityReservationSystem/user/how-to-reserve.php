<?php 


?>
<style>
	.back-to-top {
    position: fixed;
    bottom: 25px;
    right: 25px;
	
}
</style>

<a href="#" title="Help?">
<button href="#" class="btn btn-primary back-to-top btn-lg" data-toggle="modal" data-target="#howToReserve" role="button">
Help? <span class="glyphicon glyphicon-ok" style="color: white;"> </span></button></a>


<div class="modal fade" id="howToReserve">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        
		<div class="modal-header">
          <h5 class="modal-title text-center">Help</h5>
        </div>
        
		<div class="modal-body">
			<ul class="nav nav-pills">
				<li class="active" style="width: 49%;"><a data-toggle="pill" href="#HowToReserve">How to Reserve?</a></li>
				<li style="width: 50%;"><a data-toggle="pill" href="#Rules">Rules</a></li>
		
			</ul>

			<div class="tab-content">
			

				<div id="HowToReserve" class="tab-pane fade in active">
				<br>
					<p class="text-left">1. Sign in your account.</p>
					<p class="text-left">2. Every module has a calendar. Select between three (3) modules.</p>
					<p class="text-left">3. Select the date and the equipment you want to reserve. </p>
					<p class="text-left">4. Click <b>Submit</b>. </p>
					<p class="text-left">5. Your submitted request has now pending. </p>
					<p class="text-left">6. Pay through walk in. So that, you are able to reserved that equipment by selected date.</p>
					<p class="text-left">7. Once you already paid, admin will send you a notification that your request has been approved.</p>
					<p class="text-left">8. You can now view it at your transaction history or calendar. </p>
				</div>
				<div id="Rules" class="tab-pane fade">
				<br>
					<p class="text-left">Rule #1. Insert text.</p>
					<p class="text-left">Rule #2. Insert text.</p>
					<p class="text-left">Rule #3. Insert text </p>
					<p class="text-left">Rule #4. Insert text.</p>
					<p class="text-left">Rule #5. Insert text.</p>
					<p class="text-left">Rule #6. Insert text </p>
				</div>
			</div>			
        </div>  
	</div>
</div>
<script>
</script>