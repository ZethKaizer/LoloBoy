<?php 
session_start();
include('connection.php');
include('tags.php');
$username = $_SESSION['username'];
if(isset($_POST['check_query'])){		
	$subquerys = mysqli_query($conn, "SELECT * FROM tbl_otherfacilities_reservation WHERE status='Paid by User' AND username='$username'"); //getting information of the user
	$events = $subquerys; /* To fetch array inside jquery script foreach $events */
	while($row = mysqli_fetch_array($subquerys)){ 
		echo '<div id="calendar"></div>';

	}

}
?>

<script>
$(document).ready(function() {
		$('#calendar').fullCalendar({
			header: {
				left: 'prev,next',
				center: 'title',
				right: 'today' //,basicWeek,basicDay <- optional but not required
			},
		//	defaultDate: '2016-01-12', //optional
		// If the user has not yet logged in, the drag and drop event disables
		// else, the drag and drop event enables
			editable: true,
			eventLimit: true, // allow "more" link when too many events
			selectable: true,
			selectHelper: true,
			// triggers modal add event
			select: function(start, end) {
				$('#ModalAdd #start').val(moment(start).format('YYYY-MM-DD HH:mm:ss'));
				$('#ModalAdd #end').val(moment(end).format('YYYY-MM-DD HH:mm:ss'));
				$('#ModalAdd').modal('show');
			},
			// triggers modal edit event by double clicking selected date
			eventRender: function(event, element) {
				element.bind('dblclick', function() {
					$('#ModalEdit #id').val(event.id);
					$('#ModalEdit #title').val(event.title);
					$('#ModalEdit #color').val(event.color);
					$('#ModalEdit').modal('show');
				});
			},
			eventDrop: function(event, delta, revertFunc) { // draggable event [can change position]

				edit(event);

			},
			
			eventResize: function(event,dayDelta,minuteDelta,revertFunc) { // draggable event [can change it's sizes depending on how many days you want to end your reservation day]

				edit(event);

			},
	
			events: [
			<?php foreach($events as $event): 
			
				$start = explode(" ", $event['start']);
				$end = explode(" ", $event['end']);
				if($start[1] == '00:00:00'){
					$start = $start[0];
				}else{
					$start = $event['start'];
				}

				if($end[1] == '00:00:00'){
					$end = $end[0];
				}else{
					$end = $event['end'];
				}
			?>
				{
					id: '<?php echo $event['id']; ?>',
					title: '<?php echo $event['title']; ?>',
					start: '<?php echo $start; ?>',
					end: '<?php echo $end; ?>',
					color: '<?php echo $event['color']; ?>',
				},
			<?php endforeach; ?>
			]
		});
		
		function edit(event){
			start = event.start.format('YYYY-MM-DD HH:mm:ss');
			if(event.end){
				end = event.end.format('YYYY-MM-DD HH:mm:ss');
			}
			else{
				end = start;
			}
			
			id =  event.id;
			
			Event = [];
			Event[0] = id;
			Event[1] = start;
			Event[2] = end;
			
			$.ajax({
			 url: 'vehicle_edit_event_date.php',
			 type: "POST",
			 data: {Event:Event},
			 success: function(rep) {
					if(rep == 'OK'){
						alert('Saved');
					}else{
						alert('Updated'); 
					}
				}
			});
		}
		
	});
</script>

