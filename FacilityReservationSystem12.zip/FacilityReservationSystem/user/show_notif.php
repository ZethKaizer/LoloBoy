<?php 
session_start();
include('connection.php');
include('tags.php');

$username = $_SESSION['username'];

$vehicle_query = mysqli_query($conn, "SELECT * FROM tbl_vehicle_reservation 
WHERE status='Paid by User' AND username='$username' ORDER BY id DESC;");

$gymnasium_query = mysqli_query($conn, "SELECT * FROM tbl_gymnasium_reservation
WHERE status='Paid by User' AND username='$username' ORDER BY id DESC");


$otherfacilities_query = mysqli_query($conn, "SELECT * FROM tbl_otherfacilities_reservation
WHERE status='Paid by User' AND username='$username' ORDER BY id DESC");




echo '<li class="dropdown-header">Gymnasium Notification</li>';

if(mysqli_num_rows($gymnasium_query) > 0){
    while($row = mysqli_fetch_array($gymnasium_query)){ 

        echo '
        <div style="font-size: 13px; background: #f9f9f9; padding: 5px; margin: 5px; width: 300px; ">
            Your request to reserve gymnasium <b>'.$row['title'].'</b>
            <br/>
            has been Reserved and Paid
        </div>
        ';
        }
}
else{
    echo 'No records yet.';

}

echo '<li class="divider"></li>';

echo '<li class="dropdown-header">Other Facilities</li>';   

if(mysqli_num_rows($otherfacilities_query) > 0){
    while($row = mysqli_fetch_array($otherfacilities_query)){ 
        echo '
        
        <div style="font-size: 13px; background: #f9f9f9; padding: 5px; margin: 5px; width: 300px; ">
            Your request to reserve vehicle <b>'.$row['title'].'</b>
            <br/>
            has been Reserved and Paid
        </div>
        ';
        }
}
else{
    echo 'No Records Yet';
}



echo '<li class="divider"></li>';

echo '<li class="dropdown-header">Vehicle Notification</li>';   

if(mysqli_num_rows($vehicle_query) > 0){
    while($row = mysqli_fetch_array($vehicle_query)){ 
        echo '
        
        <div style="font-size: 13px; background: #f9f9f9; padding: 5px; margin: 5px; width: 300px; ">
            Your request to reserve vehicle <b>'.$row['title'].'</b>
            <br/>
            has been Reserved and Paid
        </div>
        ';
        }
}
else{
    echo 'No Records Yet';
}



/*
else {
    echo '<li class="text-center" style="padding: 5px;">No new Notification</li>';
                 
}
*/

?>
