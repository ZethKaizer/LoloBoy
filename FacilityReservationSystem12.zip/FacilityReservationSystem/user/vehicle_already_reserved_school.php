<?php 

    include('connection.php');
    include('tags.php');
session_start();    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php 
        include('header.php');
    ?>

    <div class='container fontStyle' style='margin-top: 150px;'>
    <div class='row'>
    <div class='well well-lg col-md-8 col-md-offset-2' style='border: solid 1px blue; background-color: #90d0ff; ' >
        <h1 class='text-center'>Request not sent.</h1>
       <h1 class='text-center lead'>This date has been reserved by school, please select a new one.<br>
       <a href="vehicle_reservation.php" class='lead'>Back to Vehicle Reservation</a> </h1>
       </div>
    </div>
    </div>
</body>
</html>