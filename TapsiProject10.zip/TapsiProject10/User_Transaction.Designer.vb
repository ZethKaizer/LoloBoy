﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class User_Transaction
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(User_Transaction))
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.BunifuElipse1 = New Bunifu.Framework.UI.BunifuElipse(Me.components)
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.MetroTabControl1 = New MetroFramework.Controls.MetroTabControl()
        Me.MetroTabPage1 = New MetroFramework.Controls.MetroTabPage()
        Me.MetroButton13 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton14 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton15 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton16 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton9 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton10 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton11 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton12 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton5 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton6 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton7 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton8 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton4 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton3 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton2 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton1 = New MetroFramework.Controls.MetroButton()
        Me.MetroTabPage4 = New MetroFramework.Controls.MetroTabPage()
        Me.MetroTabPage7 = New MetroFramework.Controls.MetroTabPage()
        Me.MetroTabPage8 = New MetroFramework.Controls.MetroTabPage()
        Me.MetroTabPage9 = New MetroFramework.Controls.MetroTabPage()
        Me.MetroTabPage2 = New MetroFramework.Controls.MetroTabPage()
        Me.MetroTabPage3 = New MetroFramework.Controls.MetroTabPage()
        Me.MetroTabPage5 = New MetroFramework.Controls.MetroTabPage()
        Me.MetroTabPage6 = New MetroFramework.Controls.MetroTabPage()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        Me.PrintPreviewDialog1 = New System.Windows.Forms.PrintPreviewDialog()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.MetroButton19 = New MetroFramework.Controls.MetroButton()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.MetroButton18 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton17 = New MetroFramework.Controls.MetroButton()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.MetroGrid1 = New MetroFramework.Controls.MetroGrid()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.MetroButton20 = New MetroFramework.Controls.MetroButton()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.MetroTabControl1.SuspendLayout()
        Me.MetroTabPage1.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel5.SuspendLayout()
        CType(Me.MetroGrid1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'BunifuElipse1
        '
        Me.BunifuElipse1.ElipseRadius = 5
        Me.BunifuElipse1.TargetControl = Me
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(186, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Panel1.Controls.Add(Me.MetroButton20)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1040, 101)
        Me.Panel1.TabIndex = 0
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Segoe UI Semibold", 20.25!)
        Me.Label7.Location = New System.Drawing.Point(246, 23)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(81, 37)
        Me.Label7.TabIndex = 7
        Me.Label7.Text = "Date:"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.TapsiProject.My.Resources.Resources.TapsiLogo
        Me.PictureBox1.Location = New System.Drawing.Point(12, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(113, 99)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 6
        Me.PictureBox1.TabStop = False
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.Control
        Me.Panel2.Controls.Add(Me.MetroTabControl1)
        Me.Panel2.Controls.Add(Me.Panel3)
        Me.Panel2.Location = New System.Drawing.Point(0, 101)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(620, 529)
        Me.Panel2.TabIndex = 17
        '
        'MetroTabControl1
        '
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage1)
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage4)
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage7)
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage8)
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage9)
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage2)
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage3)
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage5)
        Me.MetroTabControl1.Controls.Add(Me.MetroTabPage6)
        Me.MetroTabControl1.Location = New System.Drawing.Point(0, 62)
        Me.MetroTabControl1.Name = "MetroTabControl1"
        Me.MetroTabControl1.SelectedIndex = 0
        Me.MetroTabControl1.Size = New System.Drawing.Size(620, 467)
        Me.MetroTabControl1.TabIndex = 3
        Me.MetroTabControl1.UseSelectable = True
        '
        'MetroTabPage1
        '
        Me.MetroTabPage1.Controls.Add(Me.MetroButton13)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton14)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton15)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton16)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton9)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton10)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton11)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton12)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton5)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton6)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton7)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton8)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton4)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton3)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton2)
        Me.MetroTabPage1.Controls.Add(Me.MetroButton1)
        Me.MetroTabPage1.HorizontalScrollbarBarColor = True
        Me.MetroTabPage1.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroTabPage1.HorizontalScrollbarSize = 10
        Me.MetroTabPage1.Location = New System.Drawing.Point(4, 38)
        Me.MetroTabPage1.Name = "MetroTabPage1"
        Me.MetroTabPage1.Size = New System.Drawing.Size(612, 425)
        Me.MetroTabPage1.TabIndex = 0
        Me.MetroTabPage1.Text = "Foods"
        Me.MetroTabPage1.VerticalScrollbarBarColor = True
        Me.MetroTabPage1.VerticalScrollbarHighlightOnWheel = False
        Me.MetroTabPage1.VerticalScrollbarSize = 10
        '
        'MetroButton13
        '
        Me.MetroButton13.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton13.Location = New System.Drawing.Point(452, 417)
        Me.MetroButton13.Name = "MetroButton13"
        Me.MetroButton13.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton13.TabIndex = 17
        Me.MetroButton13.Text = "MetroButton13"
        Me.MetroButton13.UseSelectable = True
        '
        'MetroButton14
        '
        Me.MetroButton14.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton14.Location = New System.Drawing.Point(304, 417)
        Me.MetroButton14.Name = "MetroButton14"
        Me.MetroButton14.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton14.TabIndex = 16
        Me.MetroButton14.Text = "MetroButton14"
        Me.MetroButton14.UseSelectable = True
        '
        'MetroButton15
        '
        Me.MetroButton15.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton15.Location = New System.Drawing.Point(156, 417)
        Me.MetroButton15.Name = "MetroButton15"
        Me.MetroButton15.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton15.TabIndex = 15
        Me.MetroButton15.Text = "MetroButton15"
        Me.MetroButton15.UseSelectable = True
        '
        'MetroButton16
        '
        Me.MetroButton16.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton16.Location = New System.Drawing.Point(8, 417)
        Me.MetroButton16.Name = "MetroButton16"
        Me.MetroButton16.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton16.TabIndex = 14
        Me.MetroButton16.Text = "Tapsi Combo - 80"
        Me.MetroButton16.UseCustomForeColor = True
        Me.MetroButton16.UseSelectable = True
        Me.MetroButton16.UseStyleColors = True
        '
        'MetroButton9
        '
        Me.MetroButton9.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton9.Location = New System.Drawing.Point(452, 283)
        Me.MetroButton9.Name = "MetroButton9"
        Me.MetroButton9.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton9.TabIndex = 13
        Me.MetroButton9.Text = "MetroButton9"
        Me.MetroButton9.UseSelectable = True
        '
        'MetroButton10
        '
        Me.MetroButton10.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton10.Location = New System.Drawing.Point(304, 283)
        Me.MetroButton10.Name = "MetroButton10"
        Me.MetroButton10.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton10.TabIndex = 12
        Me.MetroButton10.Text = "Lechon Kawali with " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Rice" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "100"
        Me.MetroButton10.UseSelectable = True
        '
        'MetroButton11
        '
        Me.MetroButton11.DisplayFocus = True
        Me.MetroButton11.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton11.Location = New System.Drawing.Point(156, 283)
        Me.MetroButton11.Name = "MetroButton11"
        Me.MetroButton11.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton11.TabIndex = 11
        Me.MetroButton11.Text = "Lechon Kawali " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Combo" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "135"
        Me.MetroButton11.UseSelectable = True
        '
        'MetroButton12
        '
        Me.MetroButton12.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton12.Location = New System.Drawing.Point(8, 283)
        Me.MetroButton12.Name = "MetroButton12"
        Me.MetroButton12.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton12.TabIndex = 10
        Me.MetroButton12.Text = "Chicksilog" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "90"
        Me.MetroButton12.UseCustomForeColor = True
        Me.MetroButton12.UseSelectable = True
        Me.MetroButton12.UseStyleColors = True
        '
        'MetroButton5
        '
        Me.MetroButton5.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton5.Location = New System.Drawing.Point(452, 149)
        Me.MetroButton5.Name = "MetroButton5"
        Me.MetroButton5.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton5.TabIndex = 9
        Me.MetroButton5.Text = "Chicksilog Combo" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "100"
        Me.MetroButton5.UseSelectable = True
        '
        'MetroButton6
        '
        Me.MetroButton6.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton6.Location = New System.Drawing.Point(304, 149)
        Me.MetroButton6.Name = "MetroButton6"
        Me.MetroButton6.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton6.TabIndex = 8
        Me.MetroButton6.Text = "Longsilog" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "70"
        Me.MetroButton6.UseSelectable = True
        '
        'MetroButton7
        '
        Me.MetroButton7.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton7.Location = New System.Drawing.Point(156, 149)
        Me.MetroButton7.Name = "MetroButton7"
        Me.MetroButton7.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton7.TabIndex = 7
        Me.MetroButton7.Text = "Longsilog Combo" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "80"
        Me.MetroButton7.UseSelectable = True
        '
        'MetroButton8
        '
        Me.MetroButton8.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton8.Location = New System.Drawing.Point(8, 149)
        Me.MetroButton8.Name = "MetroButton8"
        Me.MetroButton8.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton8.TabIndex = 6
        Me.MetroButton8.Text = "Tosilog" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "70"
        Me.MetroButton8.UseCustomForeColor = True
        Me.MetroButton8.UseSelectable = True
        Me.MetroButton8.UseStyleColors = True
        '
        'MetroButton4
        '
        Me.MetroButton4.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton4.Location = New System.Drawing.Point(452, 15)
        Me.MetroButton4.Name = "MetroButton4"
        Me.MetroButton4.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton4.TabIndex = 5
        Me.MetroButton4.Text = "Tosilog Combo" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "80"
        Me.MetroButton4.UseSelectable = True
        '
        'MetroButton3
        '
        Me.MetroButton3.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton3.Location = New System.Drawing.Point(304, 15)
        Me.MetroButton3.Name = "MetroButton3"
        Me.MetroButton3.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton3.TabIndex = 4
        Me.MetroButton3.Text = "Spicy Tapsilog " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "80"
        Me.MetroButton3.UseSelectable = True
        '
        'MetroButton2
        '
        Me.MetroButton2.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton2.Location = New System.Drawing.Point(156, 15)
        Me.MetroButton2.Name = "MetroButton2"
        Me.MetroButton2.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton2.TabIndex = 3
        Me.MetroButton2.Text = "Tapsilog " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "70"
        Me.MetroButton2.UseSelectable = True
        '
        'MetroButton1
        '
        Me.MetroButton1.BackColor = System.Drawing.SystemColors.Control
        Me.MetroButton1.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton1.Location = New System.Drawing.Point(8, 15)
        Me.MetroButton1.Name = "MetroButton1"
        Me.MetroButton1.Size = New System.Drawing.Size(140, 128)
        Me.MetroButton1.Style = MetroFramework.MetroColorStyle.Yellow
        Me.MetroButton1.TabIndex = 2
        Me.MetroButton1.Text = "Tapsi Combo " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "80"
        Me.MetroButton1.UseCustomBackColor = True
        Me.MetroButton1.UseCustomForeColor = True
        Me.MetroButton1.UseSelectable = True
        Me.MetroButton1.UseStyleColors = True
        '
        'MetroTabPage4
        '
        Me.MetroTabPage4.HorizontalScrollbarBarColor = True
        Me.MetroTabPage4.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroTabPage4.HorizontalScrollbarSize = 10
        Me.MetroTabPage4.Location = New System.Drawing.Point(4, 38)
        Me.MetroTabPage4.Name = "MetroTabPage4"
        Me.MetroTabPage4.Size = New System.Drawing.Size(612, 425)
        Me.MetroTabPage4.TabIndex = 3
        Me.MetroTabPage4.Text = "Ala Carte"
        Me.MetroTabPage4.VerticalScrollbarBarColor = True
        Me.MetroTabPage4.VerticalScrollbarHighlightOnWheel = False
        Me.MetroTabPage4.VerticalScrollbarSize = 10
        '
        'MetroTabPage7
        '
        Me.MetroTabPage7.HorizontalScrollbarBarColor = True
        Me.MetroTabPage7.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroTabPage7.HorizontalScrollbarSize = 10
        Me.MetroTabPage7.Location = New System.Drawing.Point(4, 38)
        Me.MetroTabPage7.Name = "MetroTabPage7"
        Me.MetroTabPage7.Size = New System.Drawing.Size(612, 425)
        Me.MetroTabPage7.TabIndex = 6
        Me.MetroTabPage7.Text = "Short Orders"
        Me.MetroTabPage7.VerticalScrollbarBarColor = True
        Me.MetroTabPage7.VerticalScrollbarHighlightOnWheel = False
        Me.MetroTabPage7.VerticalScrollbarSize = 10
        '
        'MetroTabPage8
        '
        Me.MetroTabPage8.HorizontalScrollbarBarColor = True
        Me.MetroTabPage8.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroTabPage8.HorizontalScrollbarSize = 10
        Me.MetroTabPage8.Location = New System.Drawing.Point(4, 38)
        Me.MetroTabPage8.Name = "MetroTabPage8"
        Me.MetroTabPage8.Size = New System.Drawing.Size(612, 425)
        Me.MetroTabPage8.TabIndex = 7
        Me.MetroTabPage8.Text = "Binalot"
        Me.MetroTabPage8.VerticalScrollbarBarColor = True
        Me.MetroTabPage8.VerticalScrollbarHighlightOnWheel = False
        Me.MetroTabPage8.VerticalScrollbarSize = 10
        '
        'MetroTabPage9
        '
        Me.MetroTabPage9.HorizontalScrollbarBarColor = True
        Me.MetroTabPage9.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroTabPage9.HorizontalScrollbarSize = 10
        Me.MetroTabPage9.Location = New System.Drawing.Point(4, 38)
        Me.MetroTabPage9.Name = "MetroTabPage9"
        Me.MetroTabPage9.Size = New System.Drawing.Size(612, 425)
        Me.MetroTabPage9.TabIndex = 8
        Me.MetroTabPage9.Text = "Other Specials"
        Me.MetroTabPage9.VerticalScrollbarBarColor = True
        Me.MetroTabPage9.VerticalScrollbarHighlightOnWheel = False
        Me.MetroTabPage9.VerticalScrollbarSize = 10
        '
        'MetroTabPage2
        '
        Me.MetroTabPage2.HorizontalScrollbarBarColor = True
        Me.MetroTabPage2.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroTabPage2.HorizontalScrollbarSize = 10
        Me.MetroTabPage2.Location = New System.Drawing.Point(4, 38)
        Me.MetroTabPage2.Name = "MetroTabPage2"
        Me.MetroTabPage2.Size = New System.Drawing.Size(612, 425)
        Me.MetroTabPage2.TabIndex = 1
        Me.MetroTabPage2.Text = "Drinks"
        Me.MetroTabPage2.VerticalScrollbarBarColor = True
        Me.MetroTabPage2.VerticalScrollbarHighlightOnWheel = False
        Me.MetroTabPage2.VerticalScrollbarSize = 10
        '
        'MetroTabPage3
        '
        Me.MetroTabPage3.HorizontalScrollbarBarColor = True
        Me.MetroTabPage3.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroTabPage3.HorizontalScrollbarSize = 10
        Me.MetroTabPage3.Location = New System.Drawing.Point(4, 38)
        Me.MetroTabPage3.Name = "MetroTabPage3"
        Me.MetroTabPage3.Size = New System.Drawing.Size(612, 425)
        Me.MetroTabPage3.TabIndex = 2
        Me.MetroTabPage3.Text = "Sandwiches"
        Me.MetroTabPage3.VerticalScrollbarBarColor = True
        Me.MetroTabPage3.VerticalScrollbarHighlightOnWheel = False
        Me.MetroTabPage3.VerticalScrollbarSize = 10
        '
        'MetroTabPage5
        '
        Me.MetroTabPage5.HorizontalScrollbarBarColor = True
        Me.MetroTabPage5.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroTabPage5.HorizontalScrollbarSize = 10
        Me.MetroTabPage5.Location = New System.Drawing.Point(4, 38)
        Me.MetroTabPage5.Name = "MetroTabPage5"
        Me.MetroTabPage5.Size = New System.Drawing.Size(612, 425)
        Me.MetroTabPage5.TabIndex = 4
        Me.MetroTabPage5.Text = "Desserts"
        Me.MetroTabPage5.VerticalScrollbarBarColor = True
        Me.MetroTabPage5.VerticalScrollbarHighlightOnWheel = False
        Me.MetroTabPage5.VerticalScrollbarSize = 10
        '
        'MetroTabPage6
        '
        Me.MetroTabPage6.HorizontalScrollbarBarColor = True
        Me.MetroTabPage6.HorizontalScrollbarHighlightOnWheel = False
        Me.MetroTabPage6.HorizontalScrollbarSize = 10
        Me.MetroTabPage6.Location = New System.Drawing.Point(4, 38)
        Me.MetroTabPage6.Name = "MetroTabPage6"
        Me.MetroTabPage6.Size = New System.Drawing.Size(612, 425)
        Me.MetroTabPage6.TabIndex = 5
        Me.MetroTabPage6.Text = "Extras"
        Me.MetroTabPage6.VerticalScrollbarBarColor = True
        Me.MetroTabPage6.VerticalScrollbarHighlightOnWheel = False
        Me.MetroTabPage6.VerticalScrollbarSize = 10
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.Panel3.Controls.Add(Me.Label6)
        Me.Panel3.Controls.Add(Me.Label5)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel3.Location = New System.Drawing.Point(0, 0)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(620, 62)
        Me.Panel3.TabIndex = 0
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Segoe UI Semibold", 20.25!)
        Me.Label6.Location = New System.Drawing.Point(203, 11)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(33, 37)
        Me.Label6.TabIndex = 1
        Me.Label6.Text = "#"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Segoe UI Semibold", 20.25!)
        Me.Label5.Location = New System.Drawing.Point(52, 10)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(160, 37)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Transact ID:"
        '
        'PrintPreviewDialog1
        '
        Me.PrintPreviewDialog1.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.ClientSize = New System.Drawing.Size(400, 300)
        Me.PrintPreviewDialog1.Enabled = True
        Me.PrintPreviewDialog1.Icon = CType(resources.GetObject("PrintPreviewDialog1.Icon"), System.Drawing.Icon)
        Me.PrintPreviewDialog1.Name = "PrintPreviewDialog1"
        Me.PrintPreviewDialog1.Visible = False
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.Panel5)
        Me.Panel4.Controls.Add(Me.MetroGrid1)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel4.Location = New System.Drawing.Point(626, 101)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(414, 529)
        Me.Panel4.TabIndex = 18
        '
        'Panel5
        '
        Me.Panel5.Controls.Add(Me.TextBox1)
        Me.Panel5.Controls.Add(Me.MetroButton19)
        Me.Panel5.Controls.Add(Me.TextBox4)
        Me.Panel5.Controls.Add(Me.Label4)
        Me.Panel5.Controls.Add(Me.MetroButton18)
        Me.Panel5.Controls.Add(Me.MetroButton17)
        Me.Panel5.Controls.Add(Me.TextBox3)
        Me.Panel5.Controls.Add(Me.Label3)
        Me.Panel5.Controls.Add(Me.TextBox2)
        Me.Panel5.Controls.Add(Me.Label2)
        Me.Panel5.Controls.Add(Me.Label1)
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel5.Location = New System.Drawing.Point(0, 305)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(414, 224)
        Me.Panel5.TabIndex = 18
        '
        'TextBox1
        '
        Me.TextBox1.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.TextBox1.Location = New System.Drawing.Point(115, 18)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(290, 27)
        Me.TextBox1.TabIndex = 39
        '
        'MetroButton19
        '
        Me.MetroButton19.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton19.Location = New System.Drawing.Point(278, 163)
        Me.MetroButton19.Name = "MetroButton19"
        Me.MetroButton19.Size = New System.Drawing.Size(125, 43)
        Me.MetroButton19.TabIndex = 38
        Me.MetroButton19.Text = "Print Receipt"
        Me.MetroButton19.UseSelectable = True
        '
        'TextBox4
        '
        Me.TextBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox4.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox4.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.TextBox4.Location = New System.Drawing.Point(115, 126)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(290, 27)
        Me.TextBox4.TabIndex = 37
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Segoe UI Light", 11.0!)
        Me.Label4.Location = New System.Drawing.Point(48, 129)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(60, 20)
        Me.Label4.TabIndex = 36
        Me.Label4.Text = "Change:"
        '
        'MetroButton18
        '
        Me.MetroButton18.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton18.Location = New System.Drawing.Point(147, 163)
        Me.MetroButton18.Name = "MetroButton18"
        Me.MetroButton18.Size = New System.Drawing.Size(125, 43)
        Me.MetroButton18.TabIndex = 35
        Me.MetroButton18.Text = "Check Out"
        Me.MetroButton18.UseSelectable = True
        '
        'MetroButton17
        '
        Me.MetroButton17.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton17.Location = New System.Drawing.Point(16, 163)
        Me.MetroButton17.Name = "MetroButton17"
        Me.MetroButton17.Size = New System.Drawing.Size(125, 43)
        Me.MetroButton17.TabIndex = 34
        Me.MetroButton17.Text = "Cancel Item"
        Me.MetroButton17.UseSelectable = True
        '
        'TextBox3
        '
        Me.TextBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox3.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox3.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.TextBox3.Location = New System.Drawing.Point(115, 90)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(290, 27)
        Me.TextBox3.TabIndex = 33
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe UI Light", 11.0!)
        Me.Label3.Location = New System.Drawing.Point(47, 92)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(55, 20)
        Me.Label3.TabIndex = 32
        Me.Label3.Text = "Money:"
        '
        'TextBox2
        '
        Me.TextBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox2.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.TextBox2.Location = New System.Drawing.Point(115, 53)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(290, 27)
        Me.TextBox2.TabIndex = 31
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI Light", 11.0!)
        Me.Label2.Location = New System.Drawing.Point(31, 55)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(77, 20)
        Me.Label2.TabIndex = 30
        Me.Label2.Text = "Total Items:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI Light", 11.0!)
        Me.Label1.Location = New System.Drawing.Point(12, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(93, 20)
        Me.Label1.TabIndex = 29
        Me.Label1.Text = "Total Amount:"
        '
        'MetroGrid1
        '
        Me.MetroGrid1.AllowUserToResizeColumns = False
        Me.MetroGrid1.AllowUserToResizeRows = False
        DataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(CType(CType(252, Byte), Integer), CType(CType(252, Byte), Integer), CType(CType(252, Byte), Integer))
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel)
        DataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(252, Byte), Integer), CType(CType(252, Byte), Integer), CType(CType(252, Byte), Integer))
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.Black
        Me.MetroGrid1.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle5
        Me.MetroGrid1.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.MetroGrid1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.MetroGrid1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None
        Me.MetroGrid1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle6.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Segoe UI Semilight", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle6.Padding = New System.Windows.Forms.Padding(0, 8, 0, 8)
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.White
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.MetroGrid1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle6
        Me.MetroGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.MetroGrid1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2, Me.Column3})
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(CType(CType(248, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(248, Byte), Integer))
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel)
        DataGridViewCellStyle7.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.MetroGrid1.DefaultCellStyle = DataGridViewCellStyle7
        Me.MetroGrid1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MetroGrid1.EnableHeadersVisualStyles = False
        Me.MetroGrid1.Font = New System.Drawing.Font("Segoe UI", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel)
        Me.MetroGrid1.GridColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.MetroGrid1.Location = New System.Drawing.Point(0, 0)
        Me.MetroGrid1.Name = "MetroGrid1"
        Me.MetroGrid1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel)
        DataGridViewCellStyle8.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(240, Byte), Integer))
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(17, Byte), Integer))
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.MetroGrid1.RowHeadersDefaultCellStyle = DataGridViewCellStyle8
        Me.MetroGrid1.RowHeadersVisible = False
        Me.MetroGrid1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.MetroGrid1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.MetroGrid1.Size = New System.Drawing.Size(414, 529)
        Me.MetroGrid1.TabIndex = 17
        '
        'Column1
        '
        Me.Column1.HeaderText = "Item"
        Me.Column1.Name = "Column1"
        Me.Column1.Width = 200
        '
        'Column2
        '
        Me.Column2.HeaderText = "Quantity"
        Me.Column2.Name = "Column2"
        '
        'Column3
        '
        Me.Column3.HeaderText = "Amount"
        Me.Column3.Name = "Column3"
        Me.Column3.Width = 120
        '
        'MetroButton20
        '
        Me.MetroButton20.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton20.Location = New System.Drawing.Point(883, 23)
        Me.MetroButton20.Name = "MetroButton20"
        Me.MetroButton20.Size = New System.Drawing.Size(125, 43)
        Me.MetroButton20.TabIndex = 35
        Me.MetroButton20.Text = "Log Out"
        Me.MetroButton20.UseSelectable = True
        '
        'User_Transaction
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1040, 630)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "User_Transaction"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "A"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.MetroTabControl1.ResumeLayout(False)
        Me.MetroTabPage1.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        CType(Me.MetroGrid1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents BunifuElipse1 As Bunifu.Framework.UI.BunifuElipse
    Friend WithEvents Panel1 As Panel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents PrintDocument1 As Printing.PrintDocument
    Friend WithEvents PrintPreviewDialog1 As PrintPreviewDialog
    Friend WithEvents MetroTabControl1 As MetroFramework.Controls.MetroTabControl
    Friend WithEvents MetroTabPage1 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents MetroButton13 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton14 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton15 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton16 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton9 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton10 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton11 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton12 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton5 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton6 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton7 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton8 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton4 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton3 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton2 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton1 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroTabPage4 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents MetroTabPage7 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents MetroTabPage8 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents MetroTabPage9 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents MetroTabPage2 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents MetroTabPage3 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents MetroTabPage5 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents MetroTabPage6 As MetroFramework.Controls.MetroTabPage
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Panel5 As Panel
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents MetroButton19 As MetroFramework.Controls.MetroButton
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents MetroButton18 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton17 As MetroFramework.Controls.MetroButton
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents MetroGrid1 As MetroFramework.Controls.MetroGrid
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Label7 As Label
    Friend WithEvents MetroButton20 As MetroFramework.Controls.MetroButton
End Class
