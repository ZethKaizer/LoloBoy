﻿Imports System.IO
Imports MySql.Data.MySqlClient

Public Class Admin_ManageUsers

    Dim cmd As MySqlCommand
    Dim dr As MySqlDataReader
    Dim da As MySqlDataAdapter
    Dim index As Integer

    Dim ds As DataSet


    ReadOnly CONNECTION_STRING As String = "datasource=localhost;port=3306;username=root;password=;database=pos_db"
    Dim conn As New MySqlConnection(CONNECTION_STRING)
    Private Sub Admin_ManageUsers_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        loadData()
        tableHeader()
    End Sub

    Public Sub loadData()
        Dim conn As New MySqlConnection(CONNECTION_STRING)
        Dim table As New DataTable
        Dim da As New MySqlDataAdapter("Select * from tbl_user", conn)
        da.Fill(table)
        MetroGrid1.DataSource = table
        Timer1.Enabled = True
    End Sub

    Private Sub MetroButton1_Click(sender As Object, e As EventArgs) Handles MetroButton1.Click
        Me.Hide()
        Admin_CreateUser.Show()

    End Sub

    Private Sub MetroGrid1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles MetroGrid1.CellClick
        If e.RowIndex >= 0 Then
            Dim row As DataGridViewRow
            row = MetroGrid1.Rows(e.RowIndex)
            BunifuMetroTextbox1.Text = row.Cells("id").Value.ToString
            Admin_UpdateUser.Textbox_ID.Text = row.Cells("id").Value.ToString
            Admin_UpdateUser.Textbox_Name.Text = row.Cells("name").Value.ToString
            Admin_UpdateUser.Textbox_Username.Text = row.Cells("username").Value.ToString
            Admin_UpdateUser.Textbox_Pass.Text = row.Cells("password").Value.ToString
            Admin_UpdateUser.Textbox_Email.Text = row.Cells("email").Value.ToString
            Admin_UpdateUser.Combobox_Usertype.Text = row.Cells("usertype").Value.ToString
            Admin_UpdateUser.Textbox_DateCreated.Text = row.Cells("date_created").Value.ToString

        End If
    End Sub

    Private Sub MetroButton2_Click(sender As Object, e As EventArgs) Handles MetroButton2.Click
        If BunifuMetroTextbox1.Text = Nothing Then
            MetroFramework.MetroMessageBox.Show(Me, "Select Account to be Update!", "Select Account", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            Admin_UpdateUser.Show()
        End If
    End Sub

    Private Sub MetroButton3_Click(sender As Object, e As EventArgs) Handles MetroButton3.Click
        deleteUser()
    End Sub

    Private Sub deleteUser()
        Dim result As Integer = MetroFramework.MetroMessageBox.Show(Me, "Are you sure you want to delete? ", "System Ask", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        conn.ConnectionString = CONNECTION_STRING
        Dim dr As MySqlDataReader
        Try

            If result = DialogResult.Yes Then
                MetroFramework.MetroMessageBox.Show(Me, "Successfully Deleted! ", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

                conn.Open()
                Dim query As String
                query = "Delete from tbl_user where id = '" & BunifuMetroTextbox1.Text & "'"
                cmd = New MySqlCommand(query, conn)
                BunifuMetroTextbox1.Text = ""
                dr = cmd.ExecuteReader
                conn.Close()
                loadData()
                tableHeader()

            End If

        Catch ex As Exception

            If result = DialogResult.No Then
                MetroFramework.MetroMessageBox.Show(Me, "Nothing Changes ", "System Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                tableHeader()
            End If
        End Try
    End Sub

    Private Sub tableHeader()

        MetroGrid1.Columns(0).Width = 50
        MetroGrid1.Columns(1).Width = 200
        MetroGrid1.Columns(2).Width = 100
        MetroGrid1.Columns(3).Width = 100
        MetroGrid1.Columns(4).Width = 150
        MetroGrid1.Columns(5).Width = 100
        MetroGrid1.Columns(6).Width = 150

        MetroGrid1.Columns(0).HeaderText = "ID"
        MetroGrid1.Columns(1).HeaderText = "Name"
        MetroGrid1.Columns(2).HeaderText = "User Name"
        MetroGrid1.Columns(3).HeaderText = "Password"
        MetroGrid1.Columns(4).HeaderText = "Email"
        MetroGrid1.Columns(5).HeaderText = "User Type"
        MetroGrid1.Columns(6).HeaderText = "Date Created"
    End Sub

    Private Sub BunifuFlatButton1_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton1.Click
        Me.Hide()
        Admin_Mainform.show()
    End Sub
End Class