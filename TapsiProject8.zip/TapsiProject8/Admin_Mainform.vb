﻿Imports System.Drawing.Text
Public Class Admin_Mainform
    Private Sub Admin_Mainform_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub



    Private Sub BunifuFlatButton4_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click

    End Sub

    Private Sub BunifuFlatButton1_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton1.Click
        Me.Hide()
        Me.Show()

    End Sub

    Private Sub BunifuFlatButton4_Click_1(sender As Object, e As EventArgs) Handles BunifuFlatButton4.Click
        Me.Hide()
        Admin_ManageUsers.Show()
    End Sub
End Class