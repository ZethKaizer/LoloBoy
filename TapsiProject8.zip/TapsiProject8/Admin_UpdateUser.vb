﻿Imports MySql.Data.MySqlClient
Public Class Admin_UpdateUser
    Dim cmd As MySqlCommand
    Dim dr As MySqlDataReader
    Dim da As MySqlDataAdapter
    Dim index As Integer

    Dim ds As DataSet


    ReadOnly CONNECTION_STRING As String = "datasource=localhost;port=3306;username=root;password=;database=lrs_db"
    Dim conn As New MySqlConnection(CONNECTION_STRING)
    Private Sub MetroButton1_Click(sender As Object, e As EventArgs) Handles MetroButton1.Click
        updateUser()
    End Sub

    Private Sub updateUser()
        Dim result As Integer = MetroFramework.MetroMessageBox.Show(Me, "Are you sure you want to update this user? ", "System Ask", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        conn.ConnectionString = CONNECTION_STRING
        Dim dr As MySqlDataReader
        Try

            If result = DialogResult.Yes Then
                MetroFramework.MetroMessageBox.Show(Me, "Successfully Updated! ", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                conn.Open()
                Dim query As String
                query = "Update tbl_user Set name = '" & Textbox_Name.Text & "', username = '" & Textbox_Username.Text & "', password = '" & Textbox_Pass.Text & "', email = '" & Textbox_Email.Text & "', usertype = '" & Combobox_Usertype.Text & "' WHERE id = '" & Textbox_ID.Text & "'"
                cmd = New MySqlCommand(query, conn)
                dr = cmd.ExecuteReader
                conn.Close()


                cleardata()
                Me.Hide()

            End If

        Catch ex As Exception
            If result = DialogResult.No Then
                MetroFramework.MetroMessageBox.Show(Me, "Nothing Changes ", "System Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

            End If
        End Try


    End Sub

    Private Sub clearData()
        Textbox_Email.Text = ""
        Textbox_Name.Text = ""
        Textbox_Username.Text = ""
        Textbox_Pass.Text = ""
        Combobox_Usertype.Text = ""
    End Sub

    Private Sub MetroButton2_Click(sender As Object, e As EventArgs) Handles MetroButton2.Click
        Me.Hide()
    End Sub
End Class