﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Admin_CreateUser
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.BunifuElipse1 = New Bunifu.Framework.UI.BunifuElipse(Me.components)
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Combobox_Usertype = New MetroFramework.Controls.MetroComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Textbox_DateCreated = New MaterialSkin.Controls.MaterialSingleLineTextField()
        Me.Textbox_Email = New MaterialSkin.Controls.MaterialSingleLineTextField()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Textbox_ID = New MaterialSkin.Controls.MaterialSingleLineTextField()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Textbox_Name = New MaterialSkin.Controls.MaterialSingleLineTextField()
        Me.Textbox_Pass = New MaterialSkin.Controls.MaterialSingleLineTextField()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Textbox_Username = New MaterialSkin.Controls.MaterialSingleLineTextField()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.MetroButton2 = New MetroFramework.Controls.MetroButton()
        Me.MetroButton1 = New MetroFramework.Controls.MetroButton()
        Me.SuspendLayout()
        '
        'BunifuElipse1
        '
        Me.BunifuElipse1.ElipseRadius = 5
        Me.BunifuElipse1.TargetControl = Me
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(186, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(106, 600)
        Me.Panel1.TabIndex = 0
        '
        'Combobox_Usertype
        '
        Me.Combobox_Usertype.BackColor = System.Drawing.Color.FromArgb(CType(CType(246, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.Combobox_Usertype.FormattingEnabled = True
        Me.Combobox_Usertype.ItemHeight = 23
        Me.Combobox_Usertype.Items.AddRange(New Object() {"", "Admin", "User"})
        Me.Combobox_Usertype.Location = New System.Drawing.Point(161, 402)
        Me.Combobox_Usertype.Name = "Combobox_Usertype"
        Me.Combobox_Usertype.Size = New System.Drawing.Size(388, 29)
        Me.Combobox_Usertype.TabIndex = 120
        Me.Combobox_Usertype.UseSelectable = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Gray
        Me.Label9.Location = New System.Drawing.Point(158, 446)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(100, 21)
        Me.Label9.TabIndex = 119
        Me.Label9.Text = "Date Created"
        '
        'Textbox_DateCreated
        '
        Me.Textbox_DateCreated.Depth = 0
        Me.Textbox_DateCreated.Hint = ""
        Me.Textbox_DateCreated.Location = New System.Drawing.Point(162, 475)
        Me.Textbox_DateCreated.MouseState = MaterialSkin.MouseState.HOVER
        Me.Textbox_DateCreated.Name = "Textbox_DateCreated"
        Me.Textbox_DateCreated.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Textbox_DateCreated.SelectedText = ""
        Me.Textbox_DateCreated.SelectionLength = 0
        Me.Textbox_DateCreated.SelectionStart = 0
        Me.Textbox_DateCreated.Size = New System.Drawing.Size(387, 23)
        Me.Textbox_DateCreated.TabIndex = 117
        Me.Textbox_DateCreated.UseSystemPasswordChar = False
        '
        'Textbox_Email
        '
        Me.Textbox_Email.Depth = 0
        Me.Textbox_Email.Hint = ""
        Me.Textbox_Email.Location = New System.Drawing.Point(161, 342)
        Me.Textbox_Email.MouseState = MaterialSkin.MouseState.HOVER
        Me.Textbox_Email.Name = "Textbox_Email"
        Me.Textbox_Email.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Textbox_Email.SelectedText = ""
        Me.Textbox_Email.SelectionLength = 0
        Me.Textbox_Email.SelectionStart = 0
        Me.Textbox_Email.Size = New System.Drawing.Size(388, 23)
        Me.Textbox_Email.TabIndex = 116
        Me.Textbox_Email.UseSystemPasswordChar = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Gray
        Me.Label7.Location = New System.Drawing.Point(156, 316)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(48, 21)
        Me.Label7.TabIndex = 115
        Me.Label7.Text = "Email"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Gray
        Me.Label5.Location = New System.Drawing.Point(157, 377)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(78, 21)
        Me.Label5.TabIndex = 114
        Me.Label5.Text = "User Type"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Gray
        Me.Label2.Location = New System.Drawing.Point(156, 60)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(25, 21)
        Me.Label2.TabIndex = 107
        Me.Label2.Text = "ID"
        '
        'Textbox_ID
        '
        Me.Textbox_ID.Depth = 0
        Me.Textbox_ID.Hint = ""
        Me.Textbox_ID.Location = New System.Drawing.Point(159, 84)
        Me.Textbox_ID.MouseState = MaterialSkin.MouseState.HOVER
        Me.Textbox_ID.Name = "Textbox_ID"
        Me.Textbox_ID.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Textbox_ID.SelectedText = ""
        Me.Textbox_ID.SelectionLength = 0
        Me.Textbox_ID.SelectionStart = 0
        Me.Textbox_ID.Size = New System.Drawing.Size(390, 23)
        Me.Textbox_ID.TabIndex = 106
        Me.Textbox_ID.UseSystemPasswordChar = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Gray
        Me.Label3.Location = New System.Drawing.Point(157, 121)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(52, 21)
        Me.Label3.TabIndex = 108
        Me.Label3.Text = "Name"
        '
        'Textbox_Name
        '
        Me.Textbox_Name.Depth = 0
        Me.Textbox_Name.Hint = ""
        Me.Textbox_Name.Location = New System.Drawing.Point(159, 144)
        Me.Textbox_Name.MouseState = MaterialSkin.MouseState.HOVER
        Me.Textbox_Name.Name = "Textbox_Name"
        Me.Textbox_Name.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Textbox_Name.SelectedText = ""
        Me.Textbox_Name.SelectionLength = 0
        Me.Textbox_Name.SelectionStart = 0
        Me.Textbox_Name.Size = New System.Drawing.Size(390, 23)
        Me.Textbox_Name.TabIndex = 109
        Me.Textbox_Name.UseSystemPasswordChar = False
        '
        'Textbox_Pass
        '
        Me.Textbox_Pass.Depth = 0
        Me.Textbox_Pass.Hint = ""
        Me.Textbox_Pass.Location = New System.Drawing.Point(161, 273)
        Me.Textbox_Pass.MouseState = MaterialSkin.MouseState.HOVER
        Me.Textbox_Pass.Name = "Textbox_Pass"
        Me.Textbox_Pass.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Textbox_Pass.SelectedText = ""
        Me.Textbox_Pass.SelectionLength = 0
        Me.Textbox_Pass.SelectionStart = 0
        Me.Textbox_Pass.Size = New System.Drawing.Size(388, 23)
        Me.Textbox_Pass.TabIndex = 113
        Me.Textbox_Pass.UseSystemPasswordChar = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Gray
        Me.Label4.Location = New System.Drawing.Point(157, 180)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(88, 21)
        Me.Label4.TabIndex = 110
        Me.Label4.Text = "User Name"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Gray
        Me.Label8.Location = New System.Drawing.Point(157, 248)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(76, 21)
        Me.Label8.TabIndex = 112
        Me.Label8.Text = "Password"
        '
        'Textbox_Username
        '
        Me.Textbox_Username.Depth = 0
        Me.Textbox_Username.Hint = ""
        Me.Textbox_Username.Location = New System.Drawing.Point(160, 205)
        Me.Textbox_Username.MouseState = MaterialSkin.MouseState.HOVER
        Me.Textbox_Username.Name = "Textbox_Username"
        Me.Textbox_Username.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Textbox_Username.SelectedText = ""
        Me.Textbox_Username.SelectionLength = 0
        Me.Textbox_Username.SelectionStart = 0
        Me.Textbox_Username.Size = New System.Drawing.Size(389, 23)
        Me.Textbox_Username.TabIndex = 111
        Me.Textbox_Username.UseSystemPasswordChar = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(207, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(263, 32)
        Me.Label1.TabIndex = 121
        Me.Label1.Text = "Please Fill up The Form"
        '
        'MetroButton2
        '
        Me.MetroButton2.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton2.Location = New System.Drawing.Point(428, 516)
        Me.MetroButton2.Name = "MetroButton2"
        Me.MetroButton2.Size = New System.Drawing.Size(121, 57)
        Me.MetroButton2.Style = MetroFramework.MetroColorStyle.Yellow
        Me.MetroButton2.TabIndex = 123
        Me.MetroButton2.Text = "Cancel"
        Me.MetroButton2.UseCustomBackColor = True
        Me.MetroButton2.UseSelectable = True
        '
        'MetroButton1
        '
        Me.MetroButton1.FontSize = MetroFramework.MetroButtonSize.Medium
        Me.MetroButton1.Location = New System.Drawing.Point(289, 516)
        Me.MetroButton1.Name = "MetroButton1"
        Me.MetroButton1.Size = New System.Drawing.Size(121, 57)
        Me.MetroButton1.TabIndex = 122
        Me.MetroButton1.Text = "Add "
        Me.MetroButton1.UseSelectable = True
        '
        'Admin_CreateUser
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(603, 600)
        Me.Controls.Add(Me.MetroButton2)
        Me.Controls.Add(Me.MetroButton1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Combobox_Usertype)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Textbox_DateCreated)
        Me.Controls.Add(Me.Textbox_Email)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Textbox_ID)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Textbox_Name)
        Me.Controls.Add(Me.Textbox_Pass)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Textbox_Username)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Admin_CreateUser"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Admin_CreateUser"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents BunifuElipse1 As Bunifu.Framework.UI.BunifuElipse
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Combobox_Usertype As MetroFramework.Controls.MetroComboBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Textbox_DateCreated As MaterialSkin.Controls.MaterialSingleLineTextField
    Friend WithEvents Textbox_Email As MaterialSkin.Controls.MaterialSingleLineTextField
    Friend WithEvents Label7 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Textbox_ID As MaterialSkin.Controls.MaterialSingleLineTextField
    Friend WithEvents Label3 As Label
    Friend WithEvents Textbox_Name As MaterialSkin.Controls.MaterialSingleLineTextField
    Friend WithEvents Textbox_Pass As MaterialSkin.Controls.MaterialSingleLineTextField
    Friend WithEvents Label4 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Textbox_Username As MaterialSkin.Controls.MaterialSingleLineTextField
    Friend WithEvents Label1 As Label
    Friend WithEvents MetroButton2 As MetroFramework.Controls.MetroButton
    Friend WithEvents MetroButton1 As MetroFramework.Controls.MetroButton
End Class
