﻿Imports MySql.Data.MySqlClient

Public Class Admin_CreateUser
    Dim conn As MySqlConnection
    Dim cmd As MySqlCommand
    Dim dr As MySqlDataReader
    Dim da As MySqlDataAdapter
    Dim admin_manage_users As New Admin_ManageUsers
    Dim main As New Admin_Mainform
    ReadOnly CONNECTION_STRING As String = "datasource=localhost;port=3306;username=root;password=;database=pos_db"

    Private Sub MetroButton1_Click(sender As Object, e As EventArgs) Handles MetroButton1.Click
        adduser()
    End Sub

    Private Sub adduser()
        Try
            Dim conn As New MySqlConnection
            Dim cmd As New MySqlCommand
            conn.ConnectionString = (CONNECTION_STRING)
            conn.Open()
            cmd.Connection = conn
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "select * from tbl_user where user_username='" & Textbox_Username.Text & "'"
            dr = cmd.ExecuteReader
            If dr.HasRows Then
                MsgBox("Username Already Registered. Please Enter Another Username")
                conn.Close()
            Else
                conn.Close()
                conn.Open()
                cmd = New MySqlCommand("INSERT INTO tbl_user(user_id, user_name, user_username, user_pass, user_email, user_usertype, user_datecreated) VALUES('', '" & Textbox_Name.Text & "', '" & Textbox_Username.Text & "','" & Textbox_Pass.Text & "','" & Textbox_Email.Text & "', '" & Combobox_Usertype.Text & "', '" & Textbox_DateCreated.Text & "')", conn)
                If (Textbox_Name.Text = "" And Textbox_Username.Text = "" And Textbox_Pass.Text = "" And Textbox_Email.Text = "" And Combobox_Usertype.Text = "") Then
                    MessageBox.Show("Please enter the details")
                Else
                    cmd.ExecuteNonQuery()
                    MsgBox("Succerssfully Registered.", MsgBoxStyle.Information, "Success")
                    clearData()
                    autogenerateID()
                    admin_manage_users.loadData()
                    main.Refresh()

                    'Admin_Dashboard.showTotalUser()


                End If
                conn.Close()
            End If
            conn.Close()
        Catch ex As Exception
        End Try
    End Sub

    Private Sub autogenerateID()
        Dim cmd As MySqlCommand
        Dim CN As New MySqlConnection(CONNECTION_STRING)

        CN.Open()
        cmd = New MySqlCommand("select * from tbl_user", CN)
        cmd.Connection = CN
        Dim maxid As Object
        Dim strid As String
        Dim intid As Integer

        cmd.CommandText = "Select Max(user_id) as MaxID from tbl_user"

        maxid = cmd.ExecuteScalar

        If maxid Is DBNull.Value Then
            intid = 1
        Else
            strid = CType(maxid, String)
            intid = CType(maxid, String)
            intid = intid + 1
        End If
        Textbox_ID.Text = intid
        CN.Close()
    End Sub
    Private Sub clearData()
        Textbox_Email.Text = ""
        Textbox_Name.Text = ""
        Textbox_Username.Text = ""
        Textbox_Pass.Text = ""
        Combobox_Usertype.Text = ""
    End Sub

    Private Sub MetroButton2_Click(sender As Object, e As EventArgs) Handles MetroButton2.Click
        Me.Hide()
    End Sub
End Class