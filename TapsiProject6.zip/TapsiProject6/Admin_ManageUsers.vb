﻿Imports MySql.Data.MySqlClient

Public Class Admin_ManageUsers

    Dim cmd As MySqlCommand
    Dim dr As MySqlDataReader
    Dim da As MySqlDataAdapter


    ReadOnly CONNECTION_STRING As String = "datasource=localhost;port=3306;username=root;password=;database=pos_db"
    Dim conn As New MySqlConnection(CONNECTION_STRING)
    Private Sub Admin_ManageUsers_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        loadData()
    End Sub

    Public Sub loadData()
        Dim conn As New MySqlConnection(CONNECTION_STRING)
        Dim table As New DataTable
        Dim da As New MySqlDataAdapter("Select * from tbl_transaction", conn)
        da.Fill(table)
        MetroGrid1.DataSource = table
        Timer1.Enabled = True
    End Sub
End Class