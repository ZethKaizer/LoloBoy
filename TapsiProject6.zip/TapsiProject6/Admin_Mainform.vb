﻿Imports System.Drawing.Text
Public Class Admin_Mainform
    Private Sub Admin_Mainform_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub



    Private Sub BunifuFlatButton4_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click

    End Sub
End Class